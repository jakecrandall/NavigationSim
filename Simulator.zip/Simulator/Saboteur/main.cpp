#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <algorithm>
#include <chrono>
#include <ctime>
#include <cstring>
#include "Things.h"

using namespace std;

#define QUIT        	0
#define ADD         	1
#define ALTER       	2
#define REMOVE			3
#define SIMULATION		4
#define LOAD			5
#define SAVE			6
#define CONTROL			7
#define UNKNOWN     	9

void cleanMemory();
void moveDataLog();
void movePredictionLog();
void selectRobot(string line);
void makePresetWorld(string line);
void loadPresetWorld(string line);
void writeUpdateLine(string line);
bool simulatorOn();
bool isCharging();
void toggleSimulation(string line);
void initWorld();
int getType(string line);
void writeWorld();
void addObject(string line);
void removeObject(string line);
void alterObject(string line);
void cleanup();

vector<Obstacle *> obstacles;
vector<Robot *> robots;
vector<Charger *> chargers;
vector<CameraSensor *> cameras;

bool chargingFound = false;
bool simulatorStarted = false;

int main(int argc, char *argv[]) {
	bool simulatedSaboteur = false;
	ifstream simFP;
	bool processTerminated = false;
    if (argc > 1) {
		// there is a file specified for a simulated saboteur
		string argv1 = argv[1];
		string simName = "sims/" + argv1 + ".txt";
		simFP.open(simName);
		if (!simFP.good()) {
			cout << "sim file not found: " << simName << endl;
			simulatedSaboteur = false;
		}
		else {
			cout << "loaded the sim file" << endl;
			simulatedSaboteur = true;

			if (simulatorOn()) {
				cout << "can't run script because the simulator is already on" << endl;
				simFP.close();
				return -1;
			}
		}
	}
	
    string line;
    int typecode;
	bool quit = false;

	chrono::steady_clock::time_point laEmpieza = std::chrono::steady_clock::now();
	chrono::steady_clock::time_point ahoraMismo;

	while (!quit) {
		if (simulatedSaboteur) {
			// read the next time
			if (getline(simFP, line)) {
				double nextTime = stod(line);

				// sleep until the time has come
				usleep(nextTime * 1000000);

				ahoraMismo = std::chrono::steady_clock::now();
				double timeElapsed = (chrono::duration_cast<chrono::microseconds> (ahoraMismo - laEmpieza).count()) / 1000000.0;
				if ((isCharging() && (timeElapsed > 5.0)) || (timeElapsed > 400.0)) {
					cout << "simulation off" << endl;
					toggleSimulation("simulation off");
					break;
				}
				else {
					// find command
					getline(simFP, line);
					cout << line << endl;
				}

				if (!simulatorOn() && simulatorStarted) {
					processTerminated = true;
					cout << "simulator was stopped" << endl;
					toggleSimulation("simulation off");
					break;
				}
			}
			else {
				usleep(1000000);
				ahoraMismo = std::chrono::steady_clock::now();
				double timeElapsed = (chrono::duration_cast<chrono::microseconds> (ahoraMismo - laEmpieza).count()) / 1000000.0;
				//cout << "timeElapsed: " << timeElapsed << endl;
				while (!isCharging() && (timeElapsed < 400.0)) {
					usleep(1000000);
					ahoraMismo = std::chrono::steady_clock::now();
					timeElapsed = (chrono::duration_cast<chrono::microseconds> (ahoraMismo - laEmpieza).count()) / 1000000.0;
					//cout << "timeElapsed: " << timeElapsed << endl;

					if (!simulatorOn() && simulatorStarted) {
						processTerminated = true;
						cout << "simulator was stopped" << endl;
						toggleSimulation("simulation off");
						break;
					}
				}
				cout << "simulation off" << endl;
				toggleSimulation("simulation off");
				break;
			}
		}
		else {
			cout << "Enter command:" << endl;
			getline(cin, line);
		}
		typecode = getType(line);

		switch (typecode) {
			case QUIT:
				quit = true; 
				break;
			case ADD:
				initWorld();
				addObject(line);
				writeWorld();
				cleanup();
				break;
			case ALTER:
				initWorld();
				alterObject(line);
				writeWorld();
				cleanup();
				break;
			case REMOVE:
				initWorld();
				removeObject(line);
				writeWorld();
				cleanup();
				break;
			case SIMULATION:
				toggleSimulation(line);
				break;
			case LOAD:
				loadPresetWorld(line);
				break;
			case SAVE:
				makePresetWorld(line);
				break;
			case CONTROL:
				selectRobot(line);
				break;
			case UNKNOWN:
				cout << "unknown command" << endl;
				break;
        }
    }

	if (simulatedSaboteur && !processTerminated) {
		simFP.close();
		moveDataLog();
		movePredictionLog();
	}

	//cout << "NEED TO CLEAN UP MEMORY" << endl;
	cleanMemory();

    return 0;
}

void cleanMemory() {
	// cleanup
	for (int i = robots.size()-1; i >= 0; i--)
		delete robots[i];

	for (int i = obstacles.size()-1; i >= 0; i--)
		delete obstacles[i];

	for (int i = chargers.size()-1; i >= 0; i--)
		delete chargers[i];

	for (int i = cameras.size()-1; i >= 0; i--)
		delete cameras[i];
}

// automatically move the dataLog.txt to a place it won't get overwritten
void moveDataLog() {
	// read in the value
	ifstream input("../dataLogs/currentNum.txt");
	int num;
	input >> num;
	input.close();

	ofstream output("../dataLogs/currentNum.txt");
	output << (num+1);
	output.close();

	char mandato[1024];
	sprintf(mandato, "mv ../Robot/output/dataLog.txt ../dataLogs/dataLog%i.txt", num);
	system(mandato);
}

void movePredictionLog() {
	// read in the value
	ifstream input("../predictionLogs/currentNum.txt");
	int num;
	input >> num;
	input.close();

	ofstream output("../predictionLogs/currentNum.txt");
	output << (num+1);
	output.close();

	char mandato[1024];
	sprintf(mandato, "mv ../PerformanceAssessor/predictionLog.txt ../predictionLogs/predictionLog%i.txt", num);
	system(mandato);
}

void selectRobot(string line) {
	stringstream ss(line);
	string palabra;
	int rindex;

	ss >> palabra;
	ss >> rindex;

	ofstream of("../MundoVerdadero/State/keyFocusIndex.tmp");

	of << rindex << endl;

	of.close();

	char mandato[1024];
	strcpy(mandato, "mv ../MundoVerdadero/State/keyFocusIndex.tmp ../MundoVerdadero/State/keyFocusIndex.txt");
	system(mandato);
}

void makePresetWorld(string line) {
	stringstream ss(line);
	string preset;

	ss >> preset;
	ss >> preset;

	char mandato[1024];
	sprintf(mandato, "cp ../MundoVerdadero/State/status.txt ../MundoVerdadero/Presets/%s.txt", preset.c_str());
	system(mandato);
}

void loadPresetWorld(string line) {
	if (simulatorOn()) {
		cout << "Can't load preset world while \"simulation on\"" << endl;
		return;
	}

	stringstream ss(line);
	string preset;

	ss >> preset;
	ss >> preset;

	char mandato[1024];
	sprintf(mandato, "cp ../MundoVerdadero/Presets/%s.txt ../MundoVerdadero/State/status.txt", preset.c_str());
	system(mandato);

	sprintf(mandato, "cp ../MundoVerdadero/Presets/%s_perfstandard.txt ../MundoVerdadero/State/perfstandard.txt", preset.c_str());
	system(mandato);
}

void toggleSimulation(string line) {
	ofstream of("../MundoVerdadero/State/sim.tmp");

	stringstream ss(line);
	string msg;
	ss >> msg;
	ss >> msg;

	of << msg << endl;

	of.close();

	char mandato[1024];
	strcpy(mandato, "mv ../MundoVerdadero/State/sim.tmp ../MundoVerdadero/State/sim.txt");
	system(mandato);

	if (msg == "on") {
		//strcpy(mandato, "cd ../MundoVerdadero/SimCode && ./sim & && cd ../../Saboteur");
		strcpy(mandato, "./simulator_on.sh");
		system(mandato);

		simulatorStarted = true;
	}
}

void addObject(string line) {
	if (simulatorOn()) {
		writeUpdateLine(line);
		return;
	}

	// do this only if the simulator is off
	string what, params;
	stringstream ss(line);

	ss >> what; // the "add" command
	ss >> what;
	getline(ss, params);
	
	if (what == "robot") {
		params = to_string(robots.size()) + params;
		if (count(params.cbegin(), params.cend(), ' ') == 12)
			robots.push_back(new Robot(params));
		else
			cout << "Not right format to add robot: " << params << endl;
	}
	else if (what == "charger") {
		params = to_string(chargers.size()) + params;
		if (count(params.cbegin(), params.cend(), ' ') == 7)
			chargers.push_back(new Charger(params));
		else 
			cout << "Not right format to add charger: " << params << endl;
	}
	else if (what == "obstacle") {
		params = to_string(obstacles.size()) + params;
		if (count(params.cbegin(), params.cend(), ' ') == 7)
			obstacles.push_back(new Obstacle(params));
		else
			cout << "Not right format to add obstacle: " << params << endl;
	}
}

void alterObject(string line) {
	if (simulatorOn()) {
		writeUpdateLine(line);
		return;
	}

	// do this only if the simulator is off
	string what, params;
	int index = 99999;
	stringstream ss(line);

	ss >> what; // the "alter" command
	ss >> what;
	ss >> index;
	getline(ss, params);
	if (what == "robot") {
		if (index < robots.size()) {
			robots[index]->modify(params);
		}
		else {
			cout << "invalid robot index specified" << endl;
		}
	}
	else if (what == "charger") {
		if (index < chargers.size()) {
			chargers[index]->modify(params);
		}
		else {
			cout << "invalid charger index specified" << endl;
		}
	}
	else if (what == "obstacle") {
		if (index < obstacles.size()) {
			obstacles[index]->modify(params);
		}
		else {
			cout << "invalid obstacles index specified" << endl;
		}
	}
	else if (what == "camera") {
		if (index < cameras.size()) {
			cameras[index]->modify(params);
		}
		else {
			cout << "invalid cameras index specified" << endl;
		}
	}
}

void removeObject(string line) {
	if (simulatorOn()) {
		writeUpdateLine(line);
		return;
	}

	// do this only if the simulator is off
	string which;
	int index = 99999;
	stringstream ss(line);

	ss >> which; // the "remove" command
	ss >> which;
	ss >> index;
	if (which == "robot") {
		if (index < robots.size()) {
			Robot *goner = robots[index];
			robots.erase(robots.begin()+index);
			delete goner;
			for (int i = 0; i < robots.size(); i++)
				robots[i]->ID = i;
		}
		else {
			cout << "invalid robot index specified" << endl;
		}
	}
	else if (which == "charger") {
		if (index < chargers.size()) {
			Charger *goner = chargers[index];
			chargers.erase(chargers.begin()+index);
			delete goner;
			for (int i = 0; i < chargers.size(); i++)
				chargers[i]->ID = i;
		}
		else {
			cout << "invalid charger index specified" << endl;
		}
	}
	else if (which == "obstacle") {
		if (index < obstacles.size()) {
			Obstacle *goner = obstacles[index];
			obstacles.erase(obstacles.begin()+index);
			delete goner;
			for (int i = 0; i < obstacles.size(); i++)
				obstacles[i]->ID = i;
		}
		else {
			cout << "invalid obstacle index specified" << endl;
		}
	}
}

void writeUpdateLine(string line) {
	ofstream output("../MundoVerdadero/State/update.tmp", std::ofstream::out | std::ofstream::app);
	output << line << endl;
	output.close();

	ifstream input("../MundoVeradero/State/update.txt");
	if (input.good()) {
		input.close();
	}
	else {
		char mandato[1024];
		strcpy(mandato, "mv ../MundoVerdadero/State/update.tmp ../MundoVerdadero/State/update.txt");
		system(mandato);
	}
}

bool simulatorOn() {
	bool retval = false;

	ifstream input("..//MundoVerdadero/State/sim.txt");

	string msg;
	input >> msg;
	if (msg == "on")
		retval = true;

	input.close();

	return retval;
}

bool isCharging() {
	ifstream input("../MundoVerdadero/State/charging_0.txt");

	if (!input.good()) {
		cout << "file not found" << endl;
	}

	int val;
	bool retval = false;
	input >> val;
	if (val == 1) {
		if (chargingFound)
			retval = true;
		chargingFound = true;
	}

	input.close();

	return retval;
}

int getType(string line) {
    stringstream ss(line);
    string tipo;

    ss >> tipo;
    if (tipo == "quit")
        return QUIT;
    else if (tipo == "add")
        return ADD;
    else if (tipo == "alter")
        return ALTER;
    else if (tipo == "remove")
        return REMOVE;
	else if (tipo == "simulation")
		return SIMULATION;
	else if (tipo == "load")
		return LOAD;
	else if (tipo == "save")
		return SAVE;
	else if (tipo == "control")
		return CONTROL;

    return UNKNOWN;
}

void writeWorld() {
	//cout << "writing the world: " << robots[0]->poder << endl;
	ofstream output("../MundoVerdadero/State/statusSab.tmp");

	if (!output.fail()) {
		for (int i = 0; i < obstacles.size(); i++) {
			obstacles[i]->print(output);
		}

		for (int i = 0; i < robots.size(); i++) {
			robots[i]->print(output);
		}

		for (int i = 0; i < chargers.size(); i++) {
			chargers[i]->print(output);
		}

		for (int i = 0; i < cameras.size(); i++) {
			cameras[i]->print(output);
		}
	}
	else {
		cout << "statusSab.tmp not found" << endl;
		exit(1);
	}

	output.close();

	char mandato[1024];
	strcpy(mandato, "mv ../MundoVerdadero/State/statusSab.tmp ../MundoVerdadero/State/status.txt");
	system(mandato);
}

void initWorld() {
	
	// read status.txt
	ifstream input("../MundoVerdadero/State/status.txt");
	
	string primero, line;
	if (!input.fail()) {
		while (!input.eof()) {
			
			if (!(input >> primero)) {
				break;
			}
			
			getline(input, line);
			if (primero == "Obstacle") {
				obstacles.push_back(new Obstacle(line));
			}
			else if (primero == "Robot") {
				robots.push_back(new Robot(line));
			}
			else if (primero == "Charger") {
				chargers.push_back(new Charger(line));
			}
			else if (primero == "CameraSensor") {
				cameras.push_back(new CameraSensor(line));
			}
			else {
				// ignore everthing else for now
			}
		}
	
		input.close();
	}
	else {
		cout << "status.txt not found" << endl;
		exit(1);
	}
}

void cleanup() {
	for (int i = robots.size()-1; i >= 0; i--) {
		delete robots[i];
	}
	robots.clear();

	for (int i = obstacles.size()-1; i >= 0; i--) {
		delete obstacles[i];
	}
	obstacles.clear();

	for (int i = chargers.size()-1; i >= 0; i--) {
		delete chargers[i];
	}
	chargers.clear();

	for (int i = cameras.size()-1; i >= 0; i--) {
		delete cameras[i];
	}
	cameras.clear();
}