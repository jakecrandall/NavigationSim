#pragma once

#include <iostream>
#include <sstream>
#include <unistd.h>
#include <string>
#include <fstream>
#include <math.h>
#include <algorithm>
#include <cstring>

using namespace std;

#define MAX_DIM		1000

class Obstacle {
public:
	Obstacle() {
		cout << "incomplete obstacle constructor" << endl;
		exit(1);
	}
	
	Obstacle(string str) {
		//cout << "Obstacle: " << str << endl;
		stringstream ss(str);
		ss >> ID;
		ss >> sx;
		ss >> sy;
		ss >> ex;
		ss >> ey;
		ss >> rd;
		ss >> gn;
		ss >> bl;
	}
	
	~Obstacle() {
	}

	void modify(string params) {
		stringstream ss(params);
		string aspect;
		ss >> aspect;
		if (aspect == "segment") {
			ss >> sx;
			ss >> sy;
			ss >> ex;
			ss >> ey;
		}
		else if (aspect == "color") {
			ss >> rd;
			ss >> gn;
			ss >> bl;
		}
		else {
			cout << "unknown aspect of obstacle to modify: " << aspect << endl;
		}
	}
	
	void print(ofstream &of) {
		of << "Obstacle " << ID << " " << sx << " " << sy << " " << ex << " " << ey << " "  << rd << " " << gn << " " << bl << endl;
	}

	double sx, sy, ex, ey, rd, gn, bl;
	int ID;
};

class Robot {
public:
	Robot() {
		cout << "incomplete robot constructor" << endl;
		exit(1);
	}
	
	Robot(string str) {
		stringstream ss(str);
		ss >> ID;
		ss >> x;
		ss >> y;
		ss >> theta;
		ss >> w;
		ss >> h;
		ss >> speed;
		ss >> spin;
		ss >> bias;
		ss >> rd;
		ss >> gn;
		ss >> bl;
		ss >> poder;
	}
	
	~Robot() {
	}

	void modify(string params) {
		stringstream ss(params);
		string aspect;
		ss >> aspect;
		if (aspect == "pose") {
			ss >> x;
			ss >> y;
			ss >> theta;
		}
		else if (aspect == "size") {
			ss >> w;
			ss >> h;
		}
		else if (aspect == "color") {
			ss >> rd;
			ss >> gn;
			ss >> bl;
		}
		else if (aspect == "off") {
			//cout << "turning the robot off" << endl;
			poder = 0;
		}
		else if (aspect == "on") {
			//cout << "turning the robot on" << endl;
			poder = 1;
		}
		else if (aspect == "bias") {
			ss >> bias;
		}
		else if (aspect == "speed") {
			ss >> speed;
		}
		else if (aspect == "spin") {
			ss >> spin;
		}
		else {
			cout << "unknown aspect of robot to modify: " << aspect << endl;
		}
	}

	void print(ofstream &of) {
		//cout << "poder: " << poder << endl;
		of << "Robot " << ID << " " << x << " " << y << " " << theta << " " << w << " " << h << " "  << speed << " "  << spin << " "  << bias << " "  << rd << " " << gn << " " << bl << " " << poder << endl;
	}

	double x, y, theta, w, h, speed, spin, bias, rd, gn, bl;
	int ID, poder;
};

class Charger {
public:
	Charger() {
		cout << "incomplete Charger constructor" << endl;
		exit(1);
	}
	
	Charger(string str) {
		stringstream ss(str);
		ss >> ID;
		ss >> x;
		ss >> y;
		ss >> w;
		ss >> h;
		ss >> rd;
		ss >> gn;
		ss >> bl;
	}
	
	~Charger() {
	}

	void modify(string params) {
		stringstream ss(params);
		string aspect;
		ss >> aspect;
		if (aspect == "location") {
			ss >> x;
			ss >> y;
		}
		else if (aspect == "size") {
			ss >> w;
			ss >> h;
		}
		else if (aspect == "color") {
			ss >> rd;
			ss >> gn;
			ss >> bl;
		}
		else {
			cout << "unknown aspect of charger to modify: " << aspect << endl;
		}
	}

	void print(ofstream &of) {
		of << "Charger " << ID << " " << x << " " << y << " " << w << " " << h << " " << rd << " " << gn << " " << bl << endl;
	}

	double x, y, w, h, rd, gn, bl;
	int ID;
};

class CameraSensor {
public:
	CameraSensor() {
		cout << "incomplete CameraSensor Constructor" << endl;
		exit(1);
	}
	
	CameraSensor(string str) {
		stringstream ss(str);
		ss >> ID;
		ss >> cpos[0];
		ss >> cpos[1];
		ss >> cpos[2];
		ss >> corient[0];
		ss >> corient[1];
		ss >> corient[2];
		normalize(corient);
		ss >> angx;
		ss >> angy;
		ss >> countx;
		ss >> county;
		ss >> fr;
		ss >> fg;
		ss >> fb;
		ss >> raynoise;
		ss >> distortion;
		ss >> poder;
	}
	
	~CameraSensor() {
	}
	
	void modify(string params) {
		stringstream ss(params);
		string aspect;
		ss >> aspect;
		if (aspect == "location") {
			ss >> cpos[0];
			ss >> cpos[1];
			ss >> cpos[2];
		}
		else if (aspect == "orientation") {
			ss >> corient[0];
			ss >> corient[1];
			ss >> corient[2];
			normalize(corient);
		}
		else if (aspect == "viewangle") {
			ss >> angx;
			ss >> angy;
		}
		else if (aspect == "resolution") {
			ss >> countx;
			ss >> county;
		}
		else if (aspect == "filter") {
			ss >> fr;
			ss >> fg;
			ss >> fb;
		}
		else if (aspect == "off") {
			poder = 0;
		}
		else if (aspect == "on") {
			poder = 1;
		}
		else if (aspect == "noise") {
			ss >> raynoise;
		}
		else if (aspect == "distortion") {
			ss >> distortion;
		}
		else {
			cout << "unknown aspect of camera to modify: " << aspect << endl;
		}
	}

	void print(ofstream &of) {
		of << "CameraSensor " << ID << " " << cpos[0] << " " << cpos[1] << " " << cpos[2] << " " << corient[0] << " " << corient[1] << " " << corient[2] << " " << angx << " " << angy << " " << countx << " " << county << " " << fr << " " << fg << " " << fb << " " << raynoise << " " << distortion << " " << poder << endl;
	}

	void normalize(double ray[3]) {
		double mag = 0;
		for (int i = 0; i < 3; i++) {
			mag += ray[i] * ray[i];
		}
		mag = sqrt(mag);
		for (int i = 0; i < 3; i++) {
			ray[i] /= mag;
		}
	}
	
	double cpos[3], corient[3], angx, angy, fr, fg, fb, raynoise, distortion;
	int ID, countx, county, poder;
};



