cd ../MundoVerdadero/SimCode
./sim &
cd ../../Robot
./robot notlearning &
cd ../Saboteur
