Running the code with the interface:

1.  Compile all the code for your machine as follows:

A) In folder Viewer: javac *.java
B) In folder MundoVeradero/SimCode: g++ main.cpp -o sim
C) In folder Robot: g++ main.cpp -o robot
D) In folder Saboteur: g++ main.cpp -o saboteur

2.  What each program does:

- "Viewer" is the GUI showing what is happening in the world and gives information about the robot's sensors and system.  Press q to stop the simulation
- "sim" is a program that continually updates the robot's sensor readings and moves the robot as commanded by the program "robot".
- "robot" reads in the sensor data and then specifies the robot's actions by specifying a rate (0 means don't move; 1 means full 
    speed ahead; anything in between is slower) and a direction (0 means go straight ahead, -1 and 1 mean to spin the left/right).
- "saboteur" allows the user to start and stop the simulation and to change things about the world and the robot (sensors and controllers)

3.  How to run the code:

A) java viewer (from the folder Viewer): This pulls up the GUI

B) ./saboteur (from the folder Saboteur): This pulls up a command line that allows you to control what is going on.
    Type "simulation on" to make the robot move.  In the sims folder there are a number of "scenarios" that illustate various commands

4.  The program "robot" is the cpp controller used in the AAT stuff.  We could perhaps get a python version of the program.  It must read the 
    various sensor information which is continually updated in files stored in the folder MundoVerdadero/State and it must then tell the robot
    what to do by updating the file "robotactuators_[index].txt".  Note that any writing to this file must be done by writing to a temporary
    file and then moving that temp file to the specified name using the linux command so that the update is done automically (thus avoiding data races).







