#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;

class OneCharger : public Ch_Interface {
public:
	Mapper *map;
	Assumptions *assumptions;

	OneCharger(Mapper *_mapper, Planner *_planner, Mover *_mover, Assumptions *_assumptions) {
		map = _mapper;
		assumptions = _assumptions;
		currentStatus = true;
		nombre = "OneCharger";
	}
	
	~OneCharger() {
		//cout << "deleting OneCharger" << endl;
	}
	
	bool evaluateAssertion() {
		// see if there are enough charger points
		int chargerCount = 0;
		
		// see if the mean charger point is actually a charger point
		double aveCh[2] = {0.0, 0.0};
		
		for (int i = 0; i < map->imgwidth; i++) {
			for (int j = 0; j < map->imgheight; j++) {
				if (isCharger(map->img[i][j])) {
					chargerCount ++;
					aveCh[0] += i;
					aveCh[1] += j;
				}
			}
		}
		
		if (chargerCount < 5) {
			currentStatus = false;
			return false;
		}
		
		aveCh[0] /= chargerCount;
		aveCh[1] /= chargerCount;
		int x = (int)(aveCh[0] + 0.5);
		int y = (int)(aveCh[1] + 0.5);
		if (isCharger(map->img[x][y]) || isRobot(map->img[x][y])) {
			currentStatus = true;
			return true;
		}
	
		currentStatus = false;
		return false;
	}
	
	bool isCharger(int pixel[3]) {
		int assumedColor[3];
		assumedColor[0] = (int)(assumptions->charger_color[0] * 255);
		assumedColor[1] = (int)(assumptions->charger_color[1] * 255);
		assumedColor[2] = (int)(assumptions->charger_color[2] * 255);

		if (inRange(pixel[0], assumedColor[0], 20) && inRange(pixel[1], assumedColor[1], 20) && inRange(pixel[2], assumedColor[2], 20))
			return true;
		
		return false;
	}

	bool inRange(int val1, int val2, int threshold) {
		if (abs(val1-val2) <= threshold)
			return true;

		return false;
	}
	
	bool isRobot(int pixel[3]) {
		int assumedColor[3];
		assumedColor[0] = (int)(assumptions->robot_color[0] * 255);
		assumedColor[1] = (int)(assumptions->robot_color[1] * 255);
		assumedColor[2] = (int)(assumptions->robot_color[2] * 255);

		if (inRange(pixel[0], assumedColor[0], 20) && inRange(pixel[1], assumedColor[1], 20) && inRange(pixel[2], assumedColor[2], 20))
			return true;
		
		return false;
	}
};
