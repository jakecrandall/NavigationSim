#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;

#define NUM_IMAGES	10
#define MAX_RES		1001

class LowCameraNoise : public Ch_Interface {
public:
	Mapper *map;
	int numHist;
	bool obst[NUM_IMAGES][MAX_RES][MAX_RES]; // assumes camera resolution is less than MAX_RES x MAX_RES
	int curIndex;
	bool active;
	long lastCRead;

	LowCameraNoise(Mapper *_mapper, Planner *_planner, Mover *_mover, Assumptions *_assumptions) {
		map = _mapper;
		currentStatus = true;
		curIndex = lastCRead = 0;
		active = false;
		nombre = "LowCameraNoise";
	}
	
	~LowCameraNoise() {
		//cout << "deleting LowCameraNoise" << endl;
	}
	
	bool evaluateAssertion() {
		// check to see if we have a new camera img
		if (map->lastCameraRead == lastCRead) {
			return currentStatus;
		}

		lastCRead = map->lastCameraRead;

		int w = map->imgwidth;
		int h = map->imgheight;
		if (w > MAX_RES)
			w = MAX_RES;
		if (h > MAX_RES)
			h = MAX_RES;

		int numObst = 0;
		for (int i = 0; i < w; i++) {
			for (int j = 0; j < h; j++) {
				obst[curIndex][i][j] = map->obst[i][j];
				if (obst[curIndex][i][j])
					numObst++;
			}
		}
		
		int oldInd = curIndex;
		curIndex ++;
		if (curIndex >= NUM_IMAGES) {
			active = true;
			curIndex = 0;
		}

		// if active, compute the pixel variations in some way
		if (active && (numObst > 0)) {
			int numero = 0;
			for (int k = 0; k < NUM_IMAGES; k++) {
				if (k == oldInd)
					continue;

				for (int i = 0; i < w; i++) {
					for (int j = 0; j < h; j++) {
						if (obst[k][i][j] != obst[oldInd][i][j])
							numero ++;
					}
				}
			}
			//cout << numero << " of " << numObst << endl;

			if (numero > 4000)
				currentStatus = false;
			else
				currentStatus = true;
		}

		return currentStatus;
	}
};

