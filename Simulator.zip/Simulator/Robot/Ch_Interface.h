#pragma once

#include <iostream>
#include <string>

using namespace std;

class Ch_Interface {
public:
	Ch_Interface() {}
	virtual ~Ch_Interface() {}
	
	virtual bool evaluateAssertion() = 0;

	string nombre;
	bool currentStatus;
};
