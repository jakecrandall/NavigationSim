#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <vector>

#include "Gen_Mapper.h"

using namespace std;

struct Edge {
	Point p1, p2;
};

class Planner {
public:
	int robotIndex;
	Mapper *mapper;
	bool replan;

	double maxDistancia, currentDistancia;
	int numSegments;
	
	double dq;
	int K;
	vector<Point> V;
	vector<Edge> G;
	vector<Edge> optPath;
	

	Planner() {
		cout << "incomplete Planner constructor" << endl;
		exit(1);
	}
	
	Planner(int _ind, Mapper *_mapper) {
		robotIndex = _ind;
		mapper = _mapper;
		
		dq = 20.0;
		K = 1500;
		replan = false;
		
		maxDistancia = 0;
		currentDistancia = 99999.0;
		numSegments = 99999;
	}
	
	~Planner() {
		//cout << "maxDistancia: " << maxDistancia << endl;
	}
	
	void planRoute() {
		if ((mapper->chargerPos[0] == -99999.0) || (mapper->robotPos[0] == -99999.0)) {
			//cout << "charger or robot not in view" << endl;
			//cout << "Charger: " << mapper->chargerPos[0] << ", " << mapper->chargerPos[1] << endl;
			//cout << "Robot: " << mapper->robotPos[0] << ", " << mapper->robotPos[1] << endl;
			optPath.clear();
			return;
		}

		// check if I've reached the waypt
		if (isStuck()) {
			//cout << "I'm stuck" << endl;
			
			// find "free" point
			Point freePt;
			findFreePt(&freePt);
			
			//printf("I'm stuck at (%.1lf, %.1lf); move to (%.1lf, %.1lf)\n", mapper->robotPos[0], mapper->robotPos[1], freePt.x, freePt.y); fflush(stdout);
			
			// move to the "free" point
			optPath.clear();
			Edge edge;
			edge.p1.x = (int)(mapper->robotPos[0]+0.5);
			edge.p1.y = (int)(mapper->robotPos[1]+0.5);
			edge.p2.x = freePt.x;
			edge.p2.y = freePt.y;
			optPath.push_back(edge);
		}
		else if (replan || reachedNextWaypt()) {
			if (!onGoal()) {
				//if (replan)
				//	cout << "******** REPLANNING -- replan = true" << endl;
				//else
				//	cout << "******** REPLANNING -- reachedNextWaypt: " << optPath.size() << endl;

				RRT();
				//cout << "RRT done" << endl;
				determinePath();
				//cout << "determined path" << endl;
				writeEdges();
				//cout << "wrote edges" << endl;

				replan = false;

				double distance = pathDistance();
				if (distance > maxDistancia) {
					maxDistancia = distance;
				}
			}
		}

		if (path2Goal()) {
			currentDistancia = pathDistance();
			numSegments = optPath.size();
		}
	}

	bool path2Goal() {
		if (optPath.size() == 0)
			return false;

		if ((fabs(optPath[0].p2.x - mapper->chargerPos[0]) < mapper->assumptions->charger_width) &&
			(fabs(optPath[0].p2.y - mapper->chargerPos[1]) < mapper->assumptions->charger_height)) {
				return true;
		}

		return false;
	}

	double pathDistance() {
		double sum = 0.0;

		if (optPath.size() > 0) {
			for (int i = 0; i < optPath.size()-1; i++) {
				sum += getDist(optPath[i].p1, optPath[i].p2);
			}
			Point currentPt;
			currentPt.x = mapper->robotPos[0];
			currentPt.y = mapper->robotPos[1];
			sum += getDist(currentPt, optPath[optPath.size()-1].p2);
		}

		return sum;
	}
	
	bool reachedNextWaypt() {
		if (optPath.size() == 0)
			return true;

		int current = optPath.size() - 1;

		double theoryDist = getDist(optPath[current].p1, optPath[current].p2);
		Point curPos;
		curPos.x = mapper->robotPos[0]; curPos.y = mapper->robotPos[1];
		double actualDist = getDist(optPath[current].p1, curPos);
		
		//cout << "theoryDist: " << theoryDist << "; actualDist: " << actualDist << endl;

		if (actualDist >= theoryDist) {
			//cout << "REACHED WAYPT" << endl;
			return true;
		}
		
		return false;
	}
	
	void determinePath() {
		Point elFin, elPrincipio, current;
		elPrincipio.x = mapper->robotPos[0]; elPrincipio.y = mapper->robotPos[1];
		elFin.x = mapper->chargerPos[0]; elFin.y = mapper->chargerPos[1];
	
		current.x = elFin.x; current.y = elFin.y;
		optPath.clear();
		
		while (!veryNear(current, elPrincipio)) {
			double minCost = 999999.0;
			int ind = -1;
			for (int i = 0; i < G.size(); i++) {
				if (veryNear(current, G[i].p2) && (G[i].p2.dist < minCost)) {
					minCost = G[i].p2.dist;
					ind = i;
				}
			}
			if (ind < 0)
				break;
			
			current.x = G[ind].p1.x; current.y = G[ind].p1.y;
			optPath.push_back(G[ind]);
		}
	}
	
	bool veryNear(Point p1, Point p2) {
		if (getDist(p1, p2) <= 2.0) {
			return true;
		}
		return false;
	}
	
	void RRT() {
		V.clear();
		G.clear();
		
		Point empieza, qrand, qnew;
		Edge edge;
		int qnear;
		double mag;
		
		empieza.x = mapper->robotPos[0];
		empieza.y = mapper->robotPos[1];
		empieza.dist = 0.0;
		
		//cout << "empieza: (" << empieza.x << ", " << empieza.y << ")" << endl;
		V.push_back(empieza);
		
		for (int i = 0; i < K; i++) {
			//cout << (i+1) << " of " << K << endl;
			if ((rand() % 10) == 0) {
				qrand.x = mapper->chargerPos[0];
				qrand.y = mapper->chargerPos[1];
			}
			else {
				qrand.x = (double)(rand() % mapper->imgwidth);
				qrand.y = (double)(rand() % mapper->imgheight);
			}
			//cout << "qrand: (" << qrand.x << ", " << qrand.y << ")" << endl;

			//qnear = getClosestNeighbor(qrand);
			qnear = getCheapestNeighbor(qrand);
			
			if (qnear < 0) {
				//cout << "no path" << endl << endl;;
				continue;
			}
			
			qnew.x = qrand.x;
			qnew.y = qrand.y;
			qnew.dist = getDist(qrand, V[qnear]) + V[qnear].dist;
		
			// check to make sure the new edge isn't through an obstacle
			if (pathClear(V[qnear], qnew)) {
				V.push_back(qnew);
				edge.p1.x = V[qnear].x; edge.p1.y = V[qnear].y; edge.p1.dist = V[qnear].dist;
				edge.p2.x = qnew.x; edge.p2.y = qnew.y; edge.p2.dist = qnew.dist;
				G.push_back(edge);
				//cout << "Added path from (" << V[qnear].x << ", " << V[qnear].y << ") to (" << qnew.x << ", " << qnew.y << ")" << endl;
				//printf("Added path from (%.1lf, %.1lf) to (%.1lf, %.1lf): dist = %lf\n", V[qnear].x, V[qnear].y, qnew.x, qnew.y, qnew.dist);
				
				rewire();
			}
			else {
				//cout << "Path blocked from (" << V[qnear].x << ", " << V[qnear].y << ") to (" << qnew.x << ", " << qnew.y << ")" << endl;
			}
			//cout << endl;
		}
		//cout << "RRT finishing" << endl;
	}
	
	void rewire() {
		int qnew = V.size() - 1;
		double d;
		for (int i = 0; i < G.size()-1; i++) {
			// would it be better to go to point G[i].p2 from G[i].p1 or V[qnew]
			d = V[qnew].dist + getDist(V[qnew], G[i].p2);
			if (d < G[i].p2.dist) {
				if (pathClear(V[qnew], G[i].p2)) {
					//cout << "******** rewiring" << endl;
					G[i].p1.x = V[qnew].x;
					G[i].p1.y = V[qnew].y;
					G[i].p1.dist = V[qnew].dist;
					G[i].p2.dist = d;
				}
			}
		}
	}
	
	bool pathClear(Point p1, Point p2) {
		//printf("For edge (%.1lf, %.1lf) to (%.1lf, %.1lf):\n", p1.x, p1.y, p2.x, p2.y); fflush(stdout);
		double dx = p2.x - p1.x;
		double dy = p2.y - p1.y;
		double x, y;
		for (double t = 0.0; t <= 1.0049; t+=0.005) {
			x = p1.x + dx * t;
			y = p1.y + dy * t;
			//printf("\tcheck (%.1lf, %.1lf) with t = %lf\n", x, y, t);
			
			if (mapper->obst[(int)(x+0.5)][(int)(y+0.5)]) {
				//cout << "Path blocked" << endl;
				return false;
			}
		}

		//cout << "Path clear" << endl;
	
		return true;
	}
	
	int getCheapestNeighbor(Point qrand) {
		double dbest = 999999.0, d;
		int best = -1;
		for (int i = 0; i < V.size(); i++) {
			d = getDist(qrand, V[i]) + V[i].dist;
			//printf("    Point %i: %lf (%lf + %lf)\n", i, d, getDist(qrand, V[i]), V[i].dist);
			if (d < dbest) {
				if (pathClear(V[i], qrand)) {
					dbest = d;
					best = i;
				}
			}
		}
		
		//if (best < 0) {
		//	cout << "Didn't find the cheapest neighbor" << endl;
		//	exit(1);
		//}
		
		return best;
	}
	
	int getClosestNeighbor(Point qrand) {
		int closest = 0;
		double closestDist = getDist(qrand, V[0]), dist;
		for (int i = 1; i < V.size(); i++) {
			dist = getDist(qrand, V[i]);
			if (dist < closestDist) {
				closest = i;
				closestDist = dist;
			}
		}
	
		return closest;
	}
	
	double getDist(Point p1, Point p2) {
		double x = p1.x - p2.x;
		double y = p1.y - p2.y;
		return sqrt(x*x + y*y);
	}
	
	void writeEdges() {
		string fname = "output/planner_" + to_string(robotIndex) + ".tmp";
		ofstream output(fname);
		
		output << G.size() << endl;
		
		for (int i = 0; i < G.size(); i++) {
			output << G[i].p1.x << endl;
			output << G[i].p1.y << endl;
			output << G[i].p2.x << endl;
			output << G[i].p2.y << endl;
		}
		
		output.close();

		char mandato[1024];
		sprintf(mandato, "mv output/planner_%i.tmp output/planner_%i.txt", robotIndex, robotIndex);
		system(mandato);

		// also write out the chosen path
		fname = "output/optPath_" + to_string(robotIndex) + ".tmp";
		ofstream output2(fname);

		output2 << optPath.size() << endl;
		
		for (int i = 0; i < optPath.size(); i++) {
			output2 << optPath[i].p1.x << endl;
			output2 << optPath[i].p1.y << endl;
			output2 << optPath[i].p2.x << endl;
			output2 << optPath[i].p2.y << endl;
		}

		output2.close();

		sprintf(mandato, "mv output/optPath_%i.tmp output/optPath_%i.txt", robotIndex, robotIndex);
		system(mandato);
	}
	
	bool isStuck() {
		int rx = (int)(mapper->robotPos[0]+0.5);
		int ry = (int)(mapper->robotPos[1]+0.5);

		if ((rx < 0) || (ry < 0))
			return false;

		if (mapper->obst[rx][ry]) {
			return true;
		}
	
		return false;
	}
	
	void findFreePt(Point *clsst) {
		
		Point robot;
		robot.x = mapper->robotPos[0];
		robot.y = mapper->robotPos[1];
		int rx = (int)(robot.x + 0.5);
		int ry = (int)(robot.y + 0.5);
	
		Point closest;
		double bestDist = 999999, d;
		int curDist = 3;
	
		while (bestDist > 999998) {
			//cout << "iteration: " << curDist << endl;
			for (int i = -curDist; i < curDist; i++) {
				if (((ry+i) < 0) || ((ry+i) >= mapper->imgheight))
					continue;
				for (int j = -curDist; j < curDist; j++) {
					if (((rx+j) < 0) || ((rx+j) >= mapper->imgwidth))
						continue;
					//printf("%i, %i\n", rx+j, ry+i);
					if (!mapper->obst[rx+j][ry+i]) {
						d = abs(i) + abs(j);
						if (d < bestDist) {
							closest.x = robot.x+j;
							closest.y = robot.y+i;
							bestDist = d;
						}
					}
				}
			}
			curDist++;
		}
	
		clsst->x = closest.x;
		clsst->y = closest.y;
	}
	
	bool onGoal() {
		double dx = fabs(mapper->robotPos[0] - mapper->chargerPos[0]);
		double dy = fabs(mapper->robotPos[1] - mapper->chargerPos[1]);
		
		//cout << dx << ", " << dy << endl;
		
		if ((dx <= 2.0) && (dy <= 2.0)) {
			return true;
		}
		
		return false;
	}
};




