#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>
#include "Ch_Interface.h"

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;

#define MAX_POINTOS	30

class ActuatorsEngaged : public Ch_Interface {
public:
	Mapper *map;
	Mover *move;
	vector<Point> posHist;

	ActuatorsEngaged(Mapper *_mapper, Planner *_planner, Mover *_mover, Assumptions *_assumptions) {
		map = _mapper;
		move = _mover;
		currentStatus = true;
		nombre = "ActuatorsEngaged";
	}
	
	~ActuatorsEngaged() {
		//cout << "deleting ActuatorsEngaged" << endl;
	}
	
	bool evaluateAssertion() {
		if (move->direction != 0)
			return currentStatus;

		// see if the robot has moved substantially over the last N seconds going forward
		Point p;
		p.x = map->robotPos[0];
		p.y = map->robotPos[1];
		posHist.push_back(p);

		if (posHist.size() < MAX_POINTOS)
			return currentStatus;

		while (posHist.size() >= MAX_POINTOS)
			posHist.erase(posHist.begin());

		double dist = getDist(posHist[0], posHist[posHist.size()-1]);

		if (dist > 5.0)
			currentStatus = true;
		else
			currentStatus = false;

		return currentStatus;
	}

	double getDist(Point p1, Point p2) {
		double x = p1.x - p2.x;
		double y = p1.y - p2.y;
		return sqrt(x*x + y*y);
	}
};

