#include <iostream>
#include <fstream>
#include <unistd.h>
#include <string>
#include <vector>
#include <chrono>
#include <math.h>
#include <algorithm>
#include <cstring>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"
#include "PerformanceEstimator.h"

#include "Ch_Interface.h"
#include "Ch_CameraUpdated.h"
#include "Ch_ExpectedColors.h"
#include "Ch_ExpectedViewAngle.h"
#include "Ch_ExpectedCameraPlacement.h"
#include "Ch_CameraRes.h"
#include "Ch_LowCameraDistortion.h"
#include "Ch_LowCameraNoise.h"
#include "Ch_OneRobot.h"
#include "Ch_RobotInView.h"
#include "Ch_OneCharger.h"
#include "Ch_ChargerInView.h"
#include "Ch_ObstaclesVisible.h"
#include "Ch_ChargerBigger.h"
#include "Ch_ConsistentMap.h"
#include "Ch_RobotSize.h"
#include "Ch_TheresAPath.h"
#include "Ch_StationaryWorld.h"
#include "Ch_UniformCost.h"
#include "Ch_ExpectedSpinSpeed.h"
#include "Ch_RobotMovesStraight.h"
#include "Ch_ExpectedRobotSpeed.h"
#include "Ch_ActuatorsEngaged.h"
#include "Ch_ExpectedRobotMovement.h"
#include "Ch_PathToCharger.h"
#include "Ch_ApproachingGoal.h"
#include "Ch_PerformanceAcceptable.h"

using namespace std;

#define MAX_POINTS		10000

void loadAssumptions(Assumptions *assumptions, int rindex);
bool endSimulation();
vector<string> determineCheckers();
vector<Ch_Interface *> loadCheckers(vector<string> checkerList, Mapper *mapper, Planner *planner, Mover *mover, Assumptions *assumptions);
void updateCheckerEvaluations(vector<Ch_Interface *> checkers);
bool isCharging();
double getDist(Point p1, Point p2);

chrono::steady_clock::time_point lastTime;

int main(int argc, char *argv[]) {
	if (argc < 2) {
		cout << "Not enough parameters" << endl;
		return -1;
	}
	srand(time(NULL));
	
	Assumptions assumptions0;
	loadAssumptions(&assumptions0, 0);

	srand(time(NULL));

	bool learningSystem = false;
	if (!strcpy(argv[1], "learning")) {
		learningSystem = true;
	}
	
	// set of generators
	Mapper *mapper0 = new Mapper(0, &assumptions0);
	Planner *planner0 = new Planner(0, mapper0);
	Mover *mover0 = new Mover(0, planner0, &assumptions0, learningSystem);
	PerformanceEstimator *perfEstimate = new PerformanceEstimator(0, mapper0, planner0, mover0);

	vector<string> checkerList = determineCheckers();
	vector<Ch_Interface *> checkers = loadCheckers(checkerList, mapper0, planner0, mover0, &assumptions0);

	ofstream dataLog("output/dataLog.txt");
	chrono::steady_clock::time_point laEmpieza, ahoraMismo;
	laEmpieza = chrono::steady_clock::now();

	dataLog << "TimeElapsed,distTraveled,dist2Go,";
	for (int i = 0; i < checkers.size(); i++) {
		dataLog << checkers[i]->nombre << ",";
	}
	dataLog << "PerfEstimate" << endl;

	int timeSeconds = 0;
	int countCharging = 0;
	bool juststarting = true;
	bool quit = false;
	double distanceTraveled = 0.0;
	Point cur, prev;
	while (!quit) {
		//cout << "iteration" << endl;
		if (!juststarting) {
			updateCheckerEvaluations(checkers);
			//cout << "checkers updated" << endl;
		}
		juststarting = false;
	
		mapper0->createMap();
		//cout << "map created" << endl;
		planner0->planRoute();
		//cout << "plan created" << endl;
		mover0->determineActuation();
		//cout << "actuation selected" << endl;
		perfEstimate->updatePerformanceEstimate();
		//cout << "performance estimate updated" << endl;

		usleep(4000);
		quit = endSimulation();

		if (!quit) {
			if (isCharging()) {
				countCharging ++;
				perfEstimate->currentPerfEstimate = perfEstimate->timeElapsed;
				if (countCharging > 9)
					quit = true;
			}
			else {
				countCharging = 0;
			}
		}

		ahoraMismo = chrono::steady_clock::now();
		double elapsedTime = (chrono::duration_cast<chrono::microseconds> (ahoraMismo - laEmpieza).count()) / 1000000.0;
		if ((elapsedTime > (timeSeconds+1)) || quit) {
			// update distance traveled
			if (fabs(mapper0->robotPos[0]) < 9999) {
				cur.x = mapper0->robotPos[0];
				cur.y = mapper0->robotPos[1];
				if (timeSeconds > 0) {
					//cout << cur.x << ", " << cur.y << endl;
					distanceTraveled += getDist(cur, prev);
				}
				prev.x = cur.x;
				prev.y = cur.y;
			}

			// log it all
			dataLog << elapsedTime << "," << distanceTraveled << "," << planner0->currentDistancia << ",";
			for (int i = 0; i < checkers.size(); i++) {
				dataLog << (int)(checkers[i]->currentStatus) << ",";
			}
			if (!isCharging())
				dataLog << perfEstimate->currentPerfEstimate << endl;
			else {
				dataLog << perfEstimate->timeElapsed << endl;
			}

			timeSeconds++;
		}
	}

	mover0->writeActuators(0.0, 0.0);

	dataLog.close();

	delete mapper0;
	delete planner0;
	delete mover0;
	delete perfEstimate;

	//cout << "You need to delete the checkers" << endl;
	for (int i = 0; i < checkers.size(); i++) {
		delete checkers[i];
	}

	return 0;
}

vector<string> determineCheckers() {
	vector<string> checkerList;

	ifstream input("input/checkers.txt");

	string str;
	while (input >> str) {
		checkerList.push_back(str);
	}

	input.close();

	//for (int i = 0; i < checkerList.size(); i++) {
	//	cout << checkerList[i] << endl;
	//}

	return checkerList;
}

vector<Ch_Interface *> loadCheckers(vector<string> checkerList, Mapper *mapper, Planner *planner, Mover *mover, Assumptions *assumptions) {
	vector<Ch_Interface *> checkers;
	
	for (int i = 0; i < checkerList.size(); i++) {
		Ch_Interface *nChecker = NULL;
		if (checkerList[i] == "CameraUpdated")
			nChecker = new CameraUpdated(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "ExpectedColors")
			nChecker = new ExpectedColors(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "ExpectedViewAngle")
			nChecker = new ExpectedViewAngle(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "ExpectedCameraPlacement")
			nChecker = new ExpectedCameraPlacement(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "ExpectedCameraResolution")
			nChecker = new CameraRes(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "LowCameraDistortion")
			nChecker = new LowCameraDistortion(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "LowCameraNoise")
			nChecker = new LowCameraNoise(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "OneRobot")
			nChecker = new OneRobot(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "RobotVisible")
			nChecker = new RobotInView(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "OneCharger")
			nChecker = new OneCharger(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "ChargerVisible")
			nChecker = new ChargerInView(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "ObstaclesVisible")
			nChecker = new ObstaclesVisible(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "ChargerBigger")
			nChecker = new ChargerBigger(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "ConsistentMap")
			nChecker = new ConsistentMap(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "ExpectedRobotSize")
			nChecker = new RobotSize(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "TheresAPath")
			nChecker = new TheresAPath(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "StationaryWorld")
			nChecker = new StationaryWorld(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "UniformCost")
			nChecker = new UniformCost(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "ExpectedSpinSpeed")
			nChecker = new ExpectedSpinSpeed(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "RobotMovesStraight")
			nChecker = new RobotMovesStraight(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "ExpectedRobotSpeed")
			nChecker = new ExpectedRobotSpeed(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "ActuatorsEngaged")
			nChecker = new ActuatorsEngaged(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "DesirablePath")
			nChecker = new PathToCharger(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "ExpectedRobotMovement")
			nChecker = new ExpectedRobotMovement(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "ApproachingGoal")
			nChecker = new ApproachingGoal(mapper, planner, mover, assumptions);
		else if (checkerList[i] == "PerformanceAcceptable")
			nChecker = new PerformanceAcceptable(mapper, planner, mover, assumptions);

		if (nChecker != NULL)
			checkers.push_back(nChecker);
	}

	return checkers;
}

void updateCheckerEvaluations(vector<Ch_Interface *> checkers) {

	// make new evaluations
	for (int i = 0; i < checkers.size(); i++) {
		checkers[i]->evaluateAssertion();
	}

	// write the evaluations
	ofstream output("output/checkerEvaluations.tmp");

	for (int i = 0; i < checkers.size(); i++) {
		output << checkers[i]->nombre << " " << checkers[i]->currentStatus << endl;
	}

	output.close();

	char mandato[1024];
	sprintf(mandato, "mv output/checkerEvaluations.tmp output/checkerEvaluations.txt");
	system(mandato);
}

bool isCharging() {
	ifstream input("../MundoVerdadero/State/charging_0.txt");
	int charge;

	input >> charge;

	input.close();

	if (charge == 1)
		return true;

	return false;
}

bool endSimulation() {
	ifstream input("../MundoVerdadero/State/sim.txt");

	string msg;
	input >> msg;

	input.close();

	if (msg == "off")
		return true;

	return false;
}

void loadAssumptions(Assumptions *assumptions, int rindex) {
	string fnombre = "input/assumptions_" + to_string(rindex) + ".txt";
	//cout << fnombre << endl;
	ifstream input(fnombre);

	if (!input.fail()) {
		string palabra;

		input >> palabra;
		input >> assumptions->robot_color[0];
		input >> assumptions->robot_color[1];
		input >> assumptions->robot_color[2];

		//cout << "Robot color: " << assumptions->robot_color[0] << ", " << assumptions->robot_color[1] << ", " << assumptions->robot_color[2] << endl;

		input >> palabra;
		input >> assumptions->charger_color[0];
		input >> assumptions->charger_color[1];
		input >> assumptions->charger_color[2];

		//cout << "Charger color: " << assumptions->charger_color[0] << ", " << assumptions->charger_color[1] << ", " << assumptions->charger_color[1] << endl;

		input >> palabra;
		input >> assumptions->max_speed;

		input >> palabra;
		input >> assumptions->max_spin;

		input >> palabra;
		input >> assumptions->robot_radius;

		input >> palabra;
		input >> assumptions->charger_width;
		input >> assumptions->charger_height;

		input.close();
	}
	else {
		cout << "assumptions file not found" << endl;
		exit(1);
	}
}

double getDist(Point p1, Point p2) {
	double x = p1.x - p2.x;
	double y = p1.y - p2.y;
	return sqrt(x*x + y*y);
}
