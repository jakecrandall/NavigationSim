#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <vector>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;

struct PerfStandard {
	vector<string> categories;
	vector<int> lowerBounds;
};

class PerformanceEstimator {
public:
	int robotIndex;
	Mapper *mapper;
	Planner *planner;
	Mover *mover;
	PerfStandard pstand;
	double currentPerfEstimate, timeElapsed;

	PerformanceEstimator() {
		cout << "incomplete PerformanceEstimator constructor" << endl;
		exit(1);
	}
	
	PerformanceEstimator(int _ind, Mapper *_mapper, Planner *_planner, Mover *_mover) {
		robotIndex = _ind;
		mapper = _mapper;
		planner = _planner;
		mover = _mover;

		currentPerfEstimate = 99999.0;
		timeElapsed = 0.0;

		readPerformanceStandard();
	}
	
	~PerformanceEstimator() {
	}

	void readPerformanceStandard() {
		ifstream input("../MundoVerdadero/State/perfstandard.txt");
		string str;
		int val;

		while (!input.eof()) {
			input >> str;
			input >> val;
			pstand.categories.push_back(str);
			pstand.lowerBounds.push_back(val);
		}

		input.close();
	}

	void updatePerformanceEstimate() {
		timeElapsed = mover->totalTimeElapsedSoFar;
		//double time2Goal = planner->currentDistancia / 4.25;
		//cout << "numSegments: " << planner->numSegments << endl;
		double time2Goal = (4.0 * planner->numSegments) + ((planner->currentDistancia / (mapper->assumptions->max_speed * 2)) * 1.2);
		double totalEstimatedTime = time2Goal + timeElapsed;

		string fname = "output/perfestimate_" + to_string(robotIndex) + ".tmp";
		ofstream output(fname);

		output << timeElapsed << endl;
		output << time2Goal << endl;
		output << totalEstimatedTime << endl;

		currentPerfEstimate = totalEstimatedTime;

		string theCategory = findCategory(totalEstimatedTime);
		output << theCategory << endl;

		output.close();
		//cout << "Estimated distance to goal: " << planner0->currentDistancia << endl;
		//cout << "Time to goal: " << planner0->currentDistancia / 4.0 << endl;
		//cout << "Time elapsed so far: " << mover0->totalTimeElapsedSoFar << endl;
		//cout << "Total estimated time: " << ((planner0->currentDistancia / 4.0) + mover0->totalTimeElapsedSoFar) << endl;

		char mandato[1024];
		sprintf(mandato, "mv output/perfestimate_%i.tmp output/perfestimate_%i.txt", robotIndex, robotIndex);
		system(mandato);
	}

	string findCategory(double totalEstimatedTime) {
		for (int i = 0; i < pstand.lowerBounds.size()-1; i++) {
			if (totalEstimatedTime < pstand.lowerBounds[i]) {
				return pstand.categories[i];
			}
		}

		return pstand.categories[pstand.lowerBounds.size()-1];
	}
};




