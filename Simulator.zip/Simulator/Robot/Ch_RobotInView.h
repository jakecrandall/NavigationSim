#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;


class RobotInView : public Ch_Interface {
public:
	Mapper *map;
	Assumptions *assumptions;

	RobotInView(Mapper *_mapper, Planner *_planner, Mover *_mover, Assumptions *_assumptions) {
		map = _mapper;
		assumptions = _assumptions;
		currentStatus = true;
		nombre = "RobotVisible";
	}
	
	~RobotInView() {
		//cout << "deleting RobotInView" << endl;
	}
	
	bool evaluateAssertion() {
		int robotCount = 0;
		
		for (int i = 0; i < map->imgwidth; i++) {
			for (int j = 0; j < map->imgheight; j++) {
				if (isRobot(map->img[i][j])) {
					robotCount ++;
				}
			}
		}
		
		if (robotCount < 5) {
			currentStatus = false;
			return false;
		}
		currentStatus = true;
		return true;
	}
	
	bool inRange(int val1, int val2, int threshold) {
		if (abs(val1-val2) <= threshold)
			return true;

		return false;
	}
	
	bool isRobot(int pixel[3]) {
		int assumedColor[3];
		assumedColor[0] = (int)(assumptions->robot_color[0] * 255);
		assumedColor[1] = (int)(assumptions->robot_color[1] * 255);
		assumedColor[2] = (int)(assumptions->robot_color[2] * 255);

		if (inRange(pixel[0], assumedColor[0], 20) && inRange(pixel[1], assumedColor[1], 20) && inRange(pixel[2], assumedColor[2], 20))
			return true;
		
		return false;
	}
};
