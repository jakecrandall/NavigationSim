#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;

class UniformCost : public Ch_Interface {
public:
	Mapper *map;
	Assumptions *assumptions;
	Point lastPos;
	int cantidad, lastjump;

	UniformCost(Mapper *_mapper, Planner *_planner, Mover *_mover, Assumptions *_assumptions) {
		map = _mapper;
		assumptions = _assumptions;
		cantidad = 0;
		lastjump = 0;
		currentStatus = true;
		nombre = "UniformCost";
	}
	
	~UniformCost() {
		//cout << "deleting UniformCost" << endl;
	}
	
	bool evaluateAssertion() {
		// the robot shouldn't jump to a new location
		if (cantidad > 5) {
			Point npunto;
			npunto.x = map->robotPos[0];
			npunto.y = map->robotPos[1];
			if ((lastPos.x > -9999) && (lastPos.y > -9999) && (npunto.x > -9999) && (npunto.y > -9999)) {
				if (getDist(npunto, lastPos) > 5.0) {
					double dist = getDist(npunto, lastPos);
					cout << dist << endl;
					currentStatus = false;
					lastjump = cantidad;
				}
				else if ((cantidad - lastjump) > 80) {
					currentStatus = true;
				}
			}
		}
		cantidad ++;
		lastPos.x = map->robotPos[0];
		lastPos.y = map->robotPos[1];		

		// the robot's obstacle free movements when going straight ahead fast shouldn't change dramatically

		return currentStatus;
	}

	double getDist(Point p1, Point p2) {
		double x = p1.x - p2.x;
		double y = p1.y - p2.y;
		return sqrt(x*x + y*y);
	}
};
