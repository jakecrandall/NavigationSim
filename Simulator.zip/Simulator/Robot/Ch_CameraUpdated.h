#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;

class CameraUpdated : public Ch_Interface {
public:
	long lastRead, lastReceived;
	bool first;
	Mapper *map;

	CameraUpdated(Mapper *_mapper, Planner *_planner, Mover *_mover, Assumptions *_assumptions) {
		map = _mapper;
		lastRead = 0;
		first = true;
		lastReceived = 0;

		currentStatus = true;
		nombre = "CameraUpdated";
	}
	
	~CameraUpdated() {
		//cout << "deleting CameraUpdated" << endl;
	}
	
	bool evaluateAssertion() {
		long lastPicRead = map->lastCameraRead;
		bool retval = false;
		
		chrono::milliseconds ms = chrono::duration_cast< chrono::milliseconds >(chrono::steady_clock::now().time_since_epoch());
		long ahora = ms.count();
		
		//cout << lastRead << " vs " << lastPicRead << endl;
		if (lastRead < lastPicRead) {
			lastReceived = ahora;
			retval = true;
		}
		else if ((ahora - lastReceived) < 500) {
			retval = true;
		}
		
		lastRead = lastPicRead;

		currentStatus = retval;
		
		return retval;
	}
};

