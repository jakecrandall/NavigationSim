#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;

class ExpectedRobotSpeed : public Ch_Interface {
public:
	Mapper *map;
	Mover *move;
	Assumptions *assumptions;
	vector<Point> footprints;
	bool gatheringPoints;
	double rate;
	chrono::steady_clock::time_point nuevoTime, epochStart;

	ExpectedRobotSpeed(Mapper *_mapper, Planner *_planner, Mover *_mover, Assumptions *_assumptions) {
		map = _mapper;
		move = _mover;
		assumptions = _assumptions;
		currentStatus = true;
		nombre = "ExpectedRobotSpeed";
	}
	
	~ExpectedRobotSpeed() {
		//cout << "deleting ExpectedRobotSpeed" << endl;
	}
	
	bool evaluateAssertion() {
		if (move->direction == 0) {
			if (!gatheringPoints) {
				gatheringPoints = true;
				footprints.clear();
				epochStart = chrono::steady_clock::now();
				rate = 0.0;
			}
			Point p;
			p.x = map->robotPos[0];
			p.y = map->robotPos[1];
			footprints.push_back(p);

			rate += move->rate;

			if (footprints.size() > 15) {
				nuevoTime = chrono::steady_clock::now();
				double epochTime = (chrono::duration_cast<chrono::microseconds> (nuevoTime - epochStart).count()) / 1000000.0;
				double dist = getDist(footprints[0], footprints[footprints.size()-1]);
				double measuredSpeed = dist / epochTime;

				double expectedSpeed = (rate / footprints.size()) * assumptions->max_speed * 1.75;

				//cout << "measuredSpeed: " << measuredSpeed << endl;
				//cout << "expectedSpeed: " << expectedSpeed << endl;

				if ((measuredSpeed > (expectedSpeed * 0.75)) && (measuredSpeed < (expectedSpeed * 1.25))) {
					currentStatus = true;
				}
				else {
					currentStatus = false;
				}
			}
		}
		else {
			if (gatheringPoints) {
				gatheringPoints = false;
			}
		}

		return currentStatus;
	}

	double getDist(Point p1, Point p2) {
		double x = p1.x - p2.x;
		double y = p1.y - p2.y;
		return sqrt(x*x + y*y);
	}	
};
