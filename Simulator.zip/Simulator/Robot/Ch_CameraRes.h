#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;


class CameraRes : public Ch_Interface {
public:
	Mapper *map;

	CameraRes(Mapper *_mapper, Planner *_planner, Mover *_mover, Assumptions *_assumptions) {
		map = _mapper;
		currentStatus = true;
		nombre = "ExpectedCameraResolution";
	}
	
	~CameraRes() {
		//cout << "deleting CameraRes" << endl;
	}
	
	bool evaluateAssertion() {

		if ((map->imgwidth == 201) && (map->imgheight = 201))
			currentStatus = true;
		else
			currentStatus = false;
		
		return currentStatus;
	}
};

