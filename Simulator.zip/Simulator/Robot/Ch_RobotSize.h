#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;

class RobotSize : public Ch_Interface {
public:
    Mapper *map;

	RobotSize(Mapper *_mapper, Planner *_planner, Mover *_mover, Assumptions *_assumptions) {
        map = _mapper;
		currentStatus = true;
		nombre = "ExpectedRobotSize";
	}
	
	~RobotSize() {
		//cout << "deleting RobotSize" << endl;
	}
	
	bool evaluateAssertion() {
        // assumes robot footprint fits in a circles with radius of 5.0
        double maxDist = -99999.0, dist;

        Point rPos; rPos.x = map->robotPos[0]; rPos.y = map->robotPos[1];
        Point crntPt;
		for (int i = 0; i < map->imgwidth; i++) {
			for (int j = 0; j < map->imgheight; j++) {
				if (isBlue(map->img[i][j])) {
                    crntPt.x = i;
                    crntPt.y = j;
					dist = getDist(rPos, crntPt);
                    if (dist > maxDist) {
                        maxDist = dist;
                    }
				}
			}
		}

		if (maxDist < 0) {
			currentStatus = true;
			return true;
		}

        if ((maxDist > 5.9) || (maxDist < 3.1)) {
			currentStatus = false;
            return false;
        }

		currentStatus = true;
		return true;
	}

	bool isBlue(int pixel[3]) {
		if ((pixel[0] < 20) && (pixel[1] < 20) && (pixel[2] > 150))
			return true;
		
		return false;
	}

    double getDist(Point p1, Point p2) {
		double x = p1.x - p2.x;
		double y = p1.y - p2.y;
		return sqrt(x*x + y*y);
	}
};
