#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;

class ExpectedCameraPlacement : public Ch_Interface {
public:
	Mapper *map;
	Assumptions *assumptions;

	ExpectedCameraPlacement(Mapper *_mapper, Planner *_planner, Mover *_mover, Assumptions *_assumptions) {
		map = _mapper;
		assumptions = _assumptions;
		currentStatus = true;
		nombre = "ExpectedCameraPlacement";
	}
	
	~ExpectedCameraPlacement() {
		//cout << "deleting ExpectedCameraPlacement" << endl;
	}
	
	bool evaluateAssertion() {

		cout << "TODO: ExpectedCameraPlacement incomplete" << endl;

		return currentStatus;
	}
};
