#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;


class PerformanceAcceptable : public Ch_Interface {
public:
	Mapper *map;

	PerformanceAcceptable(Mapper *_mapper, Planner *_planner, Mover *_mover, Assumptions *_assumptions) {
		map = _mapper;
		currentStatus = true;
		nombre = "PerformanceAcceptable";
	}
	
	~PerformanceAcceptable() {
		//cout << "deleting PerformanceAcceptable" << endl;
	}
	
	bool evaluateAssertion() {
		// read in the threshold for acceptable performance
		ifstream input("../MundoVerdadero/State/perfstandard.txt");

		string str;
		input >> str;
		while (str != "Acceptable")
			input >> str;
		double accThreshold;
		input >> accThreshold;

		input.close();

		// read in the current estimated performance
		ifstream input2("output/perfestimate_0.txt");

		double curEstimate;
		for (int i = 0; i < 3; i++)
			input2 >> curEstimate;

		input2.close();		

		// compare them
		if (curEstimate <= accThreshold)
			currentStatus = true;
		else
			currentStatus = false;

		return currentStatus;
	}
};

