#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;

class ExpectedViewAngle : public Ch_Interface {
public:
	Mapper *map;
	Assumptions *assumptions;

	ExpectedViewAngle(Mapper *_mapper, Planner *_planner, Mover *_mover, Assumptions *_assumptions) {
		map = _mapper;
		assumptions = _assumptions;
		currentStatus = true;
		nombre = "ExpectedViewAngle";
	}
	
	~ExpectedViewAngle() {
		//cout << "deleting ExpectedViewAngle" << endl;
	}
	
	bool evaluateAssertion() {

		cout << "TODO: ExpectedViewAngle incomplete" << endl;

		return currentStatus;
	}
};
