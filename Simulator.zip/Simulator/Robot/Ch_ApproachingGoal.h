#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>
#include <list>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;

class ApproachingGoal : public Ch_Interface {
public:
	Planner *plan;
	list<double> values;

	ApproachingGoal(Mapper *_mapper, Planner *_planner, Mover *_mover, Assumptions *_assumptions) {
		plan = _planner;
		currentStatus = true;
		nombre = "ApproachingGoal";
	}
	
	~ApproachingGoal() {
		//cout << "deleting ApproachingGoal" << endl;
	}
	
	bool evaluateAssertion() {
		double nvalue = plan->currentDistancia;

		if ((values.size() == 0) && (nvalue > 99990)) {
			currentStatus = false;
			return currentStatus;
		}

		currentStatus = true;
		values.push_back(nvalue);
		int numPoints = 300;
		if (values.size() > numPoints) {
			values.erase(values.begin());
		}
		else {
			//cout << values.size() << endl;
			currentStatus = true;
			return currentStatus;
		}

		double xbar = (numPoints-1) / 2.0;
		double ybar = 0.0;
		for (list<double>::iterator iter = values.begin(); iter != values.end(); iter++) {
			ybar += *iter;
		}
		ybar /= numPoints;

		//cout << "xbar: " << xbar << "; ybar: " << ybar << endl;
		double numer = 0.0;
		double denom = 0.0;
		int count = 0;
		for (list<double>::iterator iter = values.begin(); iter != values.end(); iter++) {
			numer += (count - xbar) * (*iter - ybar);
			denom += (count - xbar) * (count - xbar);
			count ++;
		}

		double m = numer / denom;
		double b = ybar - m * xbar;

		//cout << "slope: " << m << "; intercept: " << b << endl;
		if (m < -0.2) {
			currentStatus = true;
		}
		else {
			currentStatus = false;
		}

		return currentStatus;
	}
};

