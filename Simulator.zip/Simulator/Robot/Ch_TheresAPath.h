#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;

class TheresAPath : public Ch_Interface {
public:
	Mapper *map;
	Planner *plan;
	Assumptions *assumptions;

	TheresAPath(Mapper *_mapper, Planner *_planner, Mover *_mover, Assumptions *_assumptions) {
		map = _mapper;
		plan = _planner;
		assumptions = _assumptions;
		currentStatus = true;
		nombre = "TheresAPath";
	}
	
	~TheresAPath() {
		//cout << "deleting TheresAPath" << endl;
	}
	
	bool evaluateAssertion() {
		// this function ought to be implemented independent of the generator, but ....
		//cout << "evaluating PathToCharger" << endl;

		if (plan->isStuck()) {
			return currentStatus;
		}

		//cout << "not stuck" << endl;

        if (plan->optPath.size() > 0) {
            // optPath[0] should be on the goal
            Point chrgr;
            chrgr.x = map->chargerPos[0];
            chrgr.y = map->chargerPos[1];
            if (veryNear(plan->optPath[0].p2, chrgr)) {
				currentStatus = true;
				return currentStatus;
            }
        }

		currentStatus = false;

		return currentStatus;
	}
	
    bool veryNear(Point p1, Point p2) {
		if (getDist(p1, p2) <= assumptions->charger_width) {
			return true;
		}
		return false;
	}

    double getDist(Point p1, Point p2) {
		double x = p1.x - p2.x;
		double y = p1.y - p2.y;
		return sqrt(x*x + y*y);
	}
};
