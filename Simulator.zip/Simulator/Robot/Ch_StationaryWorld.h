#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>
#include <queue>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;

#define timeGap 		0.69
#define windowHistory	10

#define WINDOW_SIZE		20
#define MAX_RESO		1001

class StationaryWorld : public Ch_Interface {
public:
	Mapper *map;
	queue<Point> chargerHist;

	bool curChargerEvaluation, curObstacleEvaluation;
	int cantidad;
	chrono::steady_clock::time_point lastTime;

	bool obst[WINDOW_SIZE][MAX_RESO][MAX_RESO]; // assumes camera resolution is less than MAX_RES x MAX_RES
	int curIndex, numFilled;
	bool obstActive;

	StationaryWorld(Mapper *_mapper, Planner *_planner, Mover *_mover, Assumptions *_assumptions) {
 		map = _mapper;
		curChargerEvaluation = curObstacleEvaluation = true;
		curIndex = numFilled = cantidad = 0;
		obstActive = false;
		currentStatus = true;
		nombre = "StationaryWorld";
	}

	~StationaryWorld() {
		//cout << "deleting StationaryWorld" << endl;
	}

	bool evaluateAssertion() {
		//cout << "cantidad: " << cantidad << endl;
		if (cantidad < 5) {
			cantidad ++;
			return curChargerEvaluation;
		}
		else if (cantidad == 5) {
			Point nuevo;
			nuevo.x = map->chargerPos[0];
			nuevo.y = map->chargerPos[1];
			//cout << "Nuevo: " << nuevo.x << ", " << nuevo.y << endl;
			chargerHist.push(nuevo);
			lastTime = std::chrono::steady_clock::now();
			cantidad ++;

			return curChargerEvaluation;
		}

		chrono::steady_clock::time_point currentTime = std::chrono::steady_clock::now();
		double timeElapsed = (chrono::duration_cast<chrono::microseconds>(currentTime - lastTime).count()) / 1000000.0;
		//cout << "timeElapsed: " << timeElapsed << endl;
		if (timeElapsed >= timeGap) {
			chargerDetermination();
			obstacleDetermination();

			lastTime = currentTime;
		}

		//if (!curChargerEvaluation || !curObstacleEvaluation)
		//	cout << ((int)curChargerEvaluation) << ", " << ((int)curObstacleEvaluation) << endl;

		if (!curChargerEvaluation || !curObstacleEvaluation)
			currentStatus = false;
		else
			currentStatus = true;

		return currentStatus;
	}

	void chargerDetermination() {
		Point nuevo;
		nuevo.x = map->chargerPos[0];
		nuevo.y = map->chargerPos[1];

		//if (chargerHist.size() >= windowHistory)
		Point prev = chargerHist.front();
		//cout << prev.x << ", " << prev.y << endl;

		if ((prev.x == -99999.0) || (nuevo.x == -99999.0)) {
			// can't really make an evaluation since charger is or was unidentified
		}
		else if (veryNear(nuevo, prev)) {
			// seems stationary recently
			curChargerEvaluation = true;
		}
		else {
			// seems non-stationary recently
			curChargerEvaluation = false;
			//cout << "Prev: " << prev.x << ", " << prev.y << endl;
			//cout << "Nuevo: " << nuevo.x << ", " << nuevo.y << endl;
		}

		chargerHist.push(nuevo);
		if (chargerHist.size() > windowHistory)
			chargerHist.pop();
	}

	void obstacleDetermination() {
		// load in the current obstacle map
		int w = map->imgwidth;
		int h = map->imgheight;
		if (w > MAX_RESO)
			w = MAX_RESO;
		if (h > MAX_RESO)
			h = MAX_RESO;

		for (int i = 0; i < w; i++) {
			for (int j = 0; j < h; j++) {
				obst[curIndex][i][j] = map->obst[i][j];
			}
		}
		numFilled ++;
		
		int oldInd = curIndex;
		curIndex ++;
		if (curIndex >= WINDOW_SIZE)
			curIndex = 0;

		if (curIndex > 2)
			obstActive = true;

		if (!obstActive) {
			return;
		}

		int cap = numFilled;
		if (numFilled > WINDOW_SIZE) {
			numFilled = WINDOW_SIZE;
		}
		int ind1 = rand() % numFilled;
		int ind2 = rand() % numFilled;
		while (ind1 == curIndex)
			ind1 = rand() % numFilled;
		while (ind2 == curIndex)
			ind2 = rand() % numFilled;
		
		//cout << ind1 << ", " << ind2 << " (" << curIndex << ")" << endl;

		//cout << "compare the obstacle maps" << endl;
		// compare the obstacle maps at oldInd and curIndex -- they should essentially be the same
		for (int i = 0; i < w; i++) {
			for (int j = 0; j < h; j++) {
				if (obst[oldInd][i][j] != obst[ind1][i][j]) {
					// check surrounding area for matches
					if (!matchingNearby(oldInd, ind1, i, j, w, h)) {
						//cout << "found violation with ind1" << endl;
						curObstacleEvaluation = false;
						return;
					}
				}
				if (obst[oldInd][i][j] != obst[ind2][i][j]) {
					// check surrounding area for matches
					if (!matchingNearby(oldInd, ind2, i, j, w, h)) {
						//cout << "found violation with ind2" << endl;
						curObstacleEvaluation = false;
						return;
					}
				}
			}
		}
		curObstacleEvaluation = true;
	}

	bool matchingNearby(int ind1, int ind2, int x, int y, int w, int h) {
		int neighborhood = 2;
		for (int i = x - neighborhood; i <= x+neighborhood; i++) {
			if ((i < 0) || (i >= w))
				continue;
			for (int j = y - neighborhood; j <= y+neighborhood; j++) {
				if ((j < 0) || (j >= h))
					continue;
				if (obst[ind1][i][j] == obst[ind2][i][j])
					return true;
			}
		}

		return false;
	}

	bool veryNear(Point p1, Point p2) {
		if (getDist(p1, p2) <= 2.0) {
			return true;
		}
		return false;
	}

	double getDist(Point p1, Point p2) {
		double x = p1.x - p2.x;
		double y = p1.y - p2.y;
		return sqrt(x * x + y * y);
	}
};
