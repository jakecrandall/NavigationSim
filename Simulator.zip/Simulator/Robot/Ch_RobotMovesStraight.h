#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;

class RobotMovesStraight : public Ch_Interface {
public:
	Mapper *map;
	Mover *move;
	Assumptions *assumptions;
	vector<Point> footprints;
	bool gatheringPoints;
	double thetaDifference;
	int totalSamples;

	RobotMovesStraight(Mapper *_mapper, Planner *_planner, Mover *_mover, Assumptions *_assumptions) {
		map = _mapper;
		move = _mover;
		assumptions = _assumptions;
		gatheringPoints = false;
		thetaDifference = 0.0;
		totalSamples = 0;
		currentStatus = true;
		nombre = "RobotMovesStraight";
	}
	
	~RobotMovesStraight() {
		//cout << "deleting RobotMovesStraight" << endl;
	}
	
	bool evaluateAssertion() {
		//cout << "TODO: RobotMovesStraight incomplete" << endl;

		// build the footprints
		if (move->direction == 0) {
			if (!gatheringPoints) {
				gatheringPoints = true;
				footprints.clear();
			}
			Point p;
			p.x = map->robotPos[0];
			p.y = map->robotPos[1];
			footprints.push_back(p);
			//cout << "gathering points" << endl;
		}
		else {
			//cout << "not gathering points" << endl;
			if (gatheringPoints) {
				gatheringPoints = false;

				computeSlopeDifference();
			}
		}

		return currentStatus;
	}

	void computeSlopeDifference() {
		int minIndex = 5;
		int minSampleSize = 6;

		if (footprints.size() < (minIndex+minSampleSize)) {
			//cout << "Not enough data to compute slope difference" << endl;
			return;
		}
			
		int midpt = ((footprints.size()-minIndex) / 2) + minIndex;
		double dx1 = footprints[midpt].x - footprints[minIndex].x;
		double dy1 = footprints[midpt].y - footprints[minIndex].y;
		double dx2 = footprints[footprints.size()-1].x - footprints[midpt].x;
		double dy2 = footprints[footprints.size()-1].y - footprints[midpt].y;

		//printf("%lf, %lf\n%lf, %lf\n%lf, %lf\n", footprints[minIndex].x, footprints[minIndex].y, footprints[midpt].x, footprints[midpt].y, footprints[footprints.size()-1].x, footprints[footprints.size()-1].y);

		if (((dx1 == 0.0) && (dy1 == 0.0)) || ((dx2 == 0.0) && (dy2 == 0.0))) {
			//cout << "Unequal sample" << endl;
			return;
		}

		double theta1 = atan2(dy1, dx1);
		double theta2 = atan2(dy2, dx2);

		//cout << "theta1: " << theta1 << "; theta2: " << theta2 << " (" << footprints.size() << ")" << endl;

		if (fabs(theta1 - theta2) > 5.5) { // atan2 returns values in [-pi, pi]
			//cout << "inverting theta1" << endl;
			//theta1 = -1.0 * theta1;
			if (theta1 < 0.0)
				theta1 += M_PI * 2.0;
			else
				theta2 += M_PI * 2.0;
		}

		totalSamples++;
		double lambda = 1.0 / (totalSamples+2);
		if (lambda < 0.2)
			lambda = 0.2;
		thetaDifference = (1 - lambda) * thetaDifference + lambda * (theta1-theta2);
		//cout << "thetaDifference (straight): " << thetaDifference << endl;

		if (fabs(thetaDifference) > 0.035) {
			currentStatus = false;
		}
		else {
			currentStatus = true;
		}
	}
};
