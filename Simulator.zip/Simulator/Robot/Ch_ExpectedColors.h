#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;

class ExpectedColors : public Ch_Interface {
public:
	Mapper *map;
	Assumptions *assumptions;

	ExpectedColors(Mapper *_mapper, Planner *_planner, Mover *_mover, Assumptions *_assumptions) {
		map = _mapper;
		assumptions = _assumptions;
		currentStatus = true;
		nombre = "ExpectedColors";
	}
	
	~ExpectedColors() {
		//cout << "deleting ExpectedColors" << endl;
	}
	
	bool evaluateAssertion() {

		// there should be:
		//		a lot of white pixels
		//		a limited number of charger-colored pixels
		//		a limited number of robot-colored pixels

		int obstacleCount = 0;
		int chargerCount = 0;
		int robotCount = 0;
		int totalPixels = map->imgwidth * map->imgheight;

		for (int i = 0; i < map->imgwidth; i++) {
			for (int j = 0; j < map->imgheight; j++) {
				if (isCharger(map->img[i][j]))
					chargerCount ++;
				else if (isRobot(map->img[i][j]))
					robotCount ++;
				else if (isObstacle(map->img[i][j]))
					obstacleCount ++;
			}
		}

		int expectedRobotCount = assumptions->robot_radius * assumptions->robot_radius * M_PI;
		int expectedChargerCount = ((assumptions->charger_height * 2)+1) * ((assumptions->charger_width * 2) + 1);

		double percentSpace = 1.0 - ((double)(obstacleCount+robotCount+chargerCount) / totalPixels);

		if (percentSpace < 0.50)
			currentStatus = false;
		else if (robotCount < 20) //(!withinBounds(robotCount, expectedRobotCount, 0.35))
			currentStatus = false;
		else if (chargerCount < 20) //(!withinBounds(chargerCount, expectedChargerCount, 0.35))
			currentStatus = false;
		else
			currentStatus = true;
		

		return currentStatus;
	}

	bool withinBounds(int count, int expectedCount, double percentError) {
		double off = expectedCount * percentError;

		if ((count > (expectedCount+off)) || (count < (expectedCount-off)))
			return false;
		
		return true;
	}

	bool inRange(int val1, int val2, int threshold) {
		if (abs(val1-val2) <= threshold)
			return true;

		return false;
	}
	
	bool isCharger(int pixel[3]) {
		int assumedColor[3];
		assumedColor[0] = (int)(assumptions->charger_color[0] * 255);
		assumedColor[1] = (int)(assumptions->charger_color[1] * 255);
		assumedColor[2] = (int)(assumptions->charger_color[2] * 255);

		if (inRange(pixel[0], assumedColor[0], 20) && inRange(pixel[1], assumedColor[1], 20) && inRange(pixel[2], assumedColor[2], 20))
			return true;
		
		return false;
	}

	bool isRobot(int pixel[3]) {
		int assumedColor[3];
		assumedColor[0] = (int)(assumptions->robot_color[0] * 255);
		assumedColor[1] = (int)(assumptions->robot_color[1] * 255);
		assumedColor[2] = (int)(assumptions->robot_color[2] * 255);

		if (inRange(pixel[0], assumedColor[0], 20) && inRange(pixel[1], assumedColor[1], 20) && inRange(pixel[2], assumedColor[2], 20))
			return true;
		
		return false;
	}

	bool isObstacle(int pixel[3]) {
		if (isRobot(pixel) || isCharger(pixel))
			return false;

		if ((pixel[0] > 230) && (pixel[1] > 230) && (pixel[2] > 230))
			return false;
		
		return true;
	}
};
