#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;


class LowCameraDistortion : public Ch_Interface {
public:
	Mapper *map;
	Assumptions *assumptions;

	LowCameraDistortion(Mapper *_mapper, Planner *_planner, Mover *_mover, Assumptions *_assumptions) {
		map = _mapper;
		assumptions = _assumptions;
		currentStatus = true;
		nombre = "LowCameraDistortion";
	}
	
	~LowCameraDistortion() {
		//cout << "deleting LowCameraDistortion" << endl;
	}
	
	bool evaluateAssertion() {	
		bool chargerWarped = false;
		bool robotWarped = false;

		// is the robot round or oval when it is in a corner?
		if (inCorner(map->robotPos[0], map->robotPos[1])) {
			int count = 0;
			double meanRobotXDown = 0.0;
			double change = 2.0 * assumptions->robot_radius;
			for (int j = map->robotPos[1] - change; j < map->robotPos[1]; j++) {
				if ((j < 0) || (j >= map->imgheight))
					continue;
				for (int i = map->robotPos[0] - change; i <= map->robotPos[0] + change; i++) {
					if ((i < 0) || (i >= map->imgwidth))
						continue;
					if (isRobot(map->img[i][j])) {
						meanRobotXDown += i;
						count ++;
					}
				}
			}
			meanRobotXDown /= count;
			//cout << "mean down: " << meanRobotXDown << endl;

			count = 0;
			double meanRobotXUp = 0.0;
			for (int j = map->robotPos[1] + 1; j <= map->robotPos[1] + change; j++) {
				if ((j < 0) || (j >= map->imgheight))
					continue;
				for (int i = map->robotPos[0] - change; i <= map->robotPos[0] + change; i++) {
					if ((i < 0) || (i >= map->imgwidth))
						continue;
					if (isRobot(map->img[i][j])) {
						meanRobotXUp += i;
						count ++;
					}
				}
			}
			meanRobotXUp /= count;
			//cout << "mean up: " << meanRobotXUp << endl;

			if (fabs(meanRobotXUp - meanRobotXDown) > 1.0) {
				robotWarped = true;
			}
		}

		// is the charger square or oval when it is in a corner?
		if (inCorner(map->chargerPos[0], map->chargerPos[1])) {
			int count = 0;
			double meanChargerXDown = 0.0;
			double xchange = 2.0 * assumptions->charger_width;
			double ychange = 2.0 * assumptions->charger_height;
			for (int j = map->chargerPos[1] - ychange; j < map->chargerPos[1]; j++) {
				if ((j < 0) || (j >= map->imgheight))
					continue;
				for (int i = map->chargerPos[0] - xchange; i <= map->chargerPos[0] + xchange; i++) {
					if ((i < 0) || (i >= map->imgwidth))
						continue;
					if (isCharger(map->img[i][j])) {
						meanChargerXDown += i;
						count ++;
					}
				}
			}
			meanChargerXDown /= count;
			//cout << "mean down: " << meanChargerXDown << endl;

			count = 0;
			double meanChargerXUp = 0.0;
			for (int j = map->chargerPos[1] + 1; j <= map->chargerPos[1] + ychange; j++) {
				if ((j < 0) || (j >= map->imgheight))
					continue;
				for (int i = map->chargerPos[0] - xchange; i <= map->chargerPos[0] + xchange; i++) {
					if ((i < 0) || (i >= map->imgwidth))
						continue;
					if (isCharger(map->img[i][j])) {
						meanChargerXUp += i;
						count ++;
					}
				}
			}
			meanChargerXUp /= count;
			//cout << "mean up: " << meanChargerXUp << endl;

			if (fabs(meanChargerXUp - meanChargerXDown) > 1.0) {
				chargerWarped = true;
			}
		}

		if (chargerWarped || robotWarped)
			currentStatus = false;
		else
			currentStatus = true;

		return currentStatus;
	}

	bool inCorner(double x, double y) {
		if ((x > (map->imgwidth * 0.65)) && (y > (map->imgheight * 0.65))) {
			return true;
		}

		if ((x < (map->imgwidth * 0.35)) && (y > (map->imgheight * 0.65))) {
			return true;
		}

		if ((x > (map->imgwidth * 0.65)) && (y < (map->imgheight * 0.35))) {
			return true;
		}

		if ((x < (map->imgwidth * 0.35)) && (y < (map->imgheight * 0.35))) {
			return true;
		}

		return false;
	}

	bool inRange(int val1, int val2, int threshold) {
		if (abs(val1-val2) <= threshold)
			return true;

		return false;
	}

	bool isCharger(int pixel[3]) {
		int assumedColor[3];
		assumedColor[0] = (int)(assumptions->charger_color[0] * 255);
		assumedColor[1] = (int)(assumptions->charger_color[1] * 255);
		assumedColor[2] = (int)(assumptions->charger_color[2] * 255);

		if (inRange(pixel[0], assumedColor[0], 20) && inRange(pixel[1], assumedColor[1], 20) && inRange(pixel[2], assumedColor[2], 20))
			return true;
		
		return false;
	}

	bool isRobot(int pixel[3]) {
		int assumedColor[3];
		assumedColor[0] = (int)(assumptions->robot_color[0] * 255);
		assumedColor[1] = (int)(assumptions->robot_color[1] * 255);
		assumedColor[2] = (int)(assumptions->robot_color[2] * 255);

		if (inRange(pixel[0], assumedColor[0], 20) && inRange(pixel[1], assumedColor[1], 20) && inRange(pixel[2], assumedColor[2], 20))
			return true;
		
		return false;
	}
};

