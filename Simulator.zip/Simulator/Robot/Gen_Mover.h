#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>

#include "Gen_Planner.h"

using namespace std;

#define SITTING			0
#define ESTIMATEPOSE	1
#define ROTATING		2
#define TRAVELING		3

class Mover {
public:
	int robotIndex;
	Planner *plan;
	Assumptions *assumptions;
	double time2Goal, totalTimeElapsedSoFar;
	bool reachedGoal;

	int travelState;
	double theta;
	
	chrono::steady_clock::time_point lastTime, phaseStart, startTime;
	Point startEstimate;
	bool thetaEstimated, estimatingPose, startedRotating;

	double rate;
	int direction;
	
	bool learningSystem;
	double spinSpeed, rotationStartTheta;

	Mover() {
		cout << "incomplete Mover constructor" << endl;
		exit(1);
	}
	
	Mover(int _ind, Planner *_plan, Assumptions *_assumptions, bool _learningSystem) {
		robotIndex = _ind;
		plan = _plan;
		assumptions = _assumptions;
		learningSystem = _learningSystem;
		spinSpeed = assumptions->max_spin;
		
		theta = 0.0;
		thetaEstimated = estimatingPose = false;
		travelState = SITTING;
		
		startTime = lastTime = chrono::steady_clock::now();
		reachedGoal = false;
		
		direction = 0;
		rate = 0.0;

		time2Goal = 99999.0;
		totalTimeElapsedSoFar = 0.0;
	}
	
	~Mover() {
		//cout << "time2Goal: " << time2Goal << endl;
	}
	
	void determineActuation() {
		chrono::steady_clock::time_point nuevoTime = std::chrono::steady_clock::now();

		totalTimeElapsedSoFar = (chrono::duration_cast<chrono::microseconds> (nuevoTime - startTime).count()) / 1000000.0;

		if (plan->optPath.size() == 0) {
			rate = 0.0;
			direction = 0;
			writeActuators(rate, direction);
			lastTime = nuevoTime;
			return;
		}
		
		int ind;
		double dx, dy, targetTheta, timeElapsed, diffTheta;
		
		int tmpDirection = 0;
		double tmpRate = 0.0;
		
		//cout << endl << "Theta: " << theta << endl;
		switch (travelState) {
			case SITTING:
				//cout << "State: SITTING" << endl;
				if (!plan->onGoal()) {
					if (!thetaEstimated) {
						travelState = ESTIMATEPOSE;
					}
					else {
						travelState = ROTATING;
					}
				}
				else {
					if (!reachedGoal) {
						time2Goal = (chrono::duration_cast<chrono::microseconds> (nuevoTime - startTime).count()) / 1000000.0;
						reachedGoal = true;
					}
				}
				break;
			case ESTIMATEPOSE:
				//cout << "State: ESTIMATINGPOSE" << endl;
				if (!thetaEstimated && !estimatingPose) {
					// start estimating pose
					tmpRate = 1.0;
					tmpDirection = 0;
				
					phaseStart = nuevoTime;
					startEstimate.x = plan->mapper->robotPos[0];
					startEstimate.y = plan->mapper->robotPos[1];
					estimatingPose = true;
				}
				else if (estimatingPose) {
					timeElapsed = (chrono::duration_cast<chrono::microseconds> (nuevoTime - phaseStart).count()) / 1000000.0;
					//cout << "timeElapsed: " << timeElapsed << endl;
					dx = plan->mapper->robotPos[0] - startEstimate.x;
					dy = plan->mapper->robotPos[1] - startEstimate.y;
					theta = normalizeAngle(atan2(dy, dx) * 180.0 / M_PI);
					//cout << "Angle = " << ((theta * 180.0) / M_PI) << endl;
					//printf("Angle = %lf (%lf, %lf)\n", theta, dy, dy);
					if (timeElapsed >= 0.5) {
						if ((fabs(dx) < 0.5) && (fabs(dy) < 0.5)) {
							// appears to not be moving
							theta = getNotMovingDirection();
							cout << "theta (after not moving): " << theta << endl;
						}
					
						tmpRate = 0.0;
						tmpDirection = 0;
						estimatingPose = false;
						thetaEstimated = true;
						travelState = ROTATING;
						startedRotating = false;
						plan->replan = true;
						//cout << "need to replan" << endl;
					}
					else {
						tmpRate = 1.0;
						tmpDirection = 0;
					}
				}
				
				break;
			case ROTATING:
				//cout << "STATE: ROTATING: " << direction << endl;
				if (plan->onGoal()) {
					travelState = SITTING;
					rate = 0.0;
					direction = -1;
					writeActuators(rate, direction);
					lastTime = nuevoTime;
				}

				if (!startedRotating) {
					phaseStart = nuevoTime;
					startedRotating = true;
					rotationStartTheta = theta;
					//cout << "starting rotation theta: " << rotationStartTheta << endl;
				}
				else {
					// update theta
					timeElapsed = (chrono::duration_cast<chrono::microseconds> (nuevoTime - lastTime).count()) / 1000000.0;
					//cout << "timeElapsed: " << timeElapsed << endl;
					double dRot = spinSpeed * rate * timeElapsed * direction;
					theta += dRot;
					theta = normalizeAngle(theta);
				}
				// determine where the next waypoint is
				ind = plan->optPath.size() - 1;
				dx = plan->optPath[ind].p2.x - plan->mapper->robotPos[0];
				dy = plan->optPath[ind].p2.y - plan->mapper->robotPos[1];
				targetTheta = normalizeAngle(atan2(dy, dx) * 180 / M_PI);


				diffTheta = normalizeAngle(targetTheta - theta);
				//cout << "theta: " << theta << endl;
				//cout << "targetTheta: " << targetTheta << endl;
				//cout << "diffTheta: " << diffTheta << endl;
				if ((diffTheta > 359.0) || (diffTheta < 1.0)) {
					tmpRate = 0.0;
					tmpDirection = 0;
					travelState = TRAVELING;
					startEstimate.x = plan->mapper->robotPos[0];
					startEstimate.y = plan->mapper->robotPos[1];
					phaseStart = nuevoTime;
				}
				else if (diffTheta > 180.0) {
					tmpRate = sqrt((360 - diffTheta) / 180.0);
					tmpDirection = -1;
				}
				else {
					tmpRate = sqrt(diffTheta / 180.0);
					tmpDirection = 1;
				}
				tmpRate *= 2.0;
				if (tmpRate > 1.0)
					tmpRate = 1.0;
				
				//cout << "rate: " << tmpRate << endl;
				//cout << "direction: " << tmpDirection << endl;
				break;
			case TRAVELING:
				//cout << "State: TRAVELING" << endl;
				if (plan->onGoal()) {
					travelState = SITTING;
					rate = 0.0;
					direction = -1;
					writeActuators(rate, direction);
					lastTime = nuevoTime;
					break;
				}
				
				Point robot;
				robot.x = plan->mapper->robotPos[0];
				robot.y = plan->mapper->robotPos[1];
				if (!plan->pathClear(robot, plan->optPath[plan->optPath.size()-1].p2)) {
					//cout << "path not clear: " << theta << endl;
					travelState = ROTATING;
					rate = 0.0;
					direction = -1;
					writeActuators(rate, direction);
					lastTime = nuevoTime;
					plan->replan = true;
				}
				
				timeElapsed = (chrono::duration_cast<chrono::microseconds> (nuevoTime - phaseStart).count()) / 1000000.0;
				//cout << "timeElapsed: " << timeElapsed << endl;
				if (timeElapsed > 3.0) {
					dx = plan->mapper->robotPos[0] - startEstimate.x;
					dy = plan->mapper->robotPos[1] - startEstimate.y;
					
					if ((fabs(dx) < 0.5) && (fabs(dy) < 0.5)) {
						cout << "appears to not be moving" << endl;
						theta = getNotMovingDirection();
						cout << "theta (after not moving): " << theta << endl;
					}
					else {
						double oldTheta = theta;
						theta = atan2(dy, dx) * 180.0 / M_PI;
						double expectedDTheta = oldTheta - rotationStartTheta;
						double dTheta = theta - rotationStartTheta;
						theta = normalizeAngle(theta);
						//cout << "Mover theta update" << endl;

						//cout << "updated theta in TRAVELING (1): " << expectedDTheta << " vs " << dTheta << endl;
					}
				}

				ind = plan->optPath.size() - 1;
				dx = plan->optPath[ind].p2.x - plan->mapper->robotPos[0];
				dy = plan->optPath[ind].p2.y - plan->mapper->robotPos[1];
				targetTheta = atan2(dy, dx) * 180 / M_PI;
				diffTheta = normalizeAngle(targetTheta - theta);
				//cout << "diffTheta: " << diffTheta << endl;
				if ((diffTheta < 2.0) || (diffTheta > 358.0)) {
					if (((plan->optPath.size() < 2) && nearGoal()))
						tmpRate = 0.1;
					else if (plan->isStuck())
						tmpRate = 0.3;
					else
						tmpRate = 1.0;
					tmpDirection = 0.0;
				}
				else {
					travelState = ROTATING;
					startedRotating = false;
					dx = plan->mapper->robotPos[0] - startEstimate.x;
					dy = plan->mapper->robotPos[1] - startEstimate.y;
					if ((fabs(dx) > 0.5) || (fabs(dy) > 0.5)) {
						double oldTheta = theta;
						theta = atan2(dy, dx) * 180.0 / M_PI;
						double expectedDTheta = oldTheta - rotationStartTheta;
						double dTheta = theta - rotationStartTheta;
						theta = normalizeAngle(theta);
						//cout << "Mover theta update (start rotating)" << endl;

						//cout << "updated theta in TRAVELING (2): " << expectedDTheta << " vs " << dTheta << endl;
					}
				}

				break;
		}
		
		//cout << "Theta: " << theta << endl;
		
		rate = tmpRate;
		direction = tmpDirection;
		
		writeActuators(rate, direction);
		
		lastTime = nuevoTime;
	}
	
	double normalizeAngle(double angle) {
		while (angle < 0.0) {
			angle += 360.0;
		}
		while (angle > 360.0) {
			angle -= 360.0;
		}
		
		return angle;
	}
	
	void writeActuators(double rate, int direction) {
		string fname = "../MundoVerdadero/State/robotactuators_" + to_string(robotIndex) + ".tmp";
		ofstream output(fname);
		
		output << "rate " << rate << endl;
		output << "direction " << direction << endl;
		
		output.close();

		char mandato[1024];
		sprintf(mandato, "mv ../MundoVerdadero/State/robotactuators_%i.tmp ../MundoVerdadero/State/robotactuators_%i.txt", robotIndex, robotIndex);
		system(mandato);
	}
	
	double getNotMovingDirection() {
		Point freePt;
		plan->findFreePt(&freePt);

		double dx = plan->mapper->robotPos[0] - freePt.x;
		double dy = plan->mapper->robotPos[1] - freePt.y;

		//cout << dx << ", " << dy << endl;
		
		double angle = (atan2(dy, dx) * 180.0 / M_PI);// + 180.0;
		
		// add a little randomness
		int rndnss = (rand() % 61) - 30;
		
		angle += rndnss;
		
		return normalizeAngle(angle);
	}
	
	bool nearGoal() {
		double dx = fabs(plan->mapper->robotPos[0] - plan->mapper->chargerPos[0]);
		double dy = fabs(plan->mapper->robotPos[1] - plan->mapper->chargerPos[1]);
		
		//cout << dx << ", " << dy << endl;
		
		if ((dx <= 6.0) && (dy <= 6.0)) {
			return true;
		}
		
		return false;
	}
};
