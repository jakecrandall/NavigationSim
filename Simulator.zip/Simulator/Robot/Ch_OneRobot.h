#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;

class OneRobot : public Ch_Interface {
public:
	Mapper *map;
	Assumptions *assumptions;

	OneRobot(Mapper *_mapper, Planner *_planner, Mover *_mover, Assumptions *_assumptions) {
		map = _mapper;
		assumptions = _assumptions;
		currentStatus = true;
		nombre = "OneRobot";
	}
	
	~OneRobot() {
		//cout << "deleting OneRobot" << endl;
	}
	
	bool evaluateAssertion() {
		// see if there are enough charger points
		int robotCount = 0;
		
		// see if the mean charger point is actually a charger point
		double aveRobot[2] = {0.0, 0.0};
		
		for (int i = 0; i < map->imgwidth; i++) {
			for (int j = 0; j < map->imgheight; j++) {
				if (isRobot(map->img[i][j])) {
					robotCount ++;
					aveRobot[0] += i;
					aveRobot[1] += j;
				}
			}
		}
		
		if (robotCount < 5) {
			currentStatus = false;
			return false;
		}
		
		aveRobot[0] /= robotCount;
		aveRobot[1] /= robotCount;
		int x = (int)(aveRobot[0] + 0.5);
		int y = (int)(aveRobot[1] + 0.5);
		if (isCharger(map->img[x][y]) || isRobot(map->img[x][y])) {
			currentStatus = true;
			return true;
		}
	
		currentStatus = false;
		return false;
	}
	
	bool isCharger(int pixel[3]) {
		int assumedColor[3];
		assumedColor[0] = (int)(assumptions->charger_color[0] * 255);
		assumedColor[1] = (int)(assumptions->charger_color[1] * 255);
		assumedColor[2] = (int)(assumptions->charger_color[2] * 255);

		if (inRange(pixel[0], assumedColor[0], 20) && inRange(pixel[1], assumedColor[1], 20) && inRange(pixel[2], assumedColor[2], 20))
			return true;
		
		return false;
	}

	bool inRange(int val1, int val2, int threshold) {
		if (abs(val1-val2) <= threshold)
			return true;

		return false;
	}
	
	bool isRobot(int pixel[3]) {
		int assumedColor[3];
		assumedColor[0] = (int)(assumptions->robot_color[0] * 255);
		assumedColor[1] = (int)(assumptions->robot_color[1] * 255);
		assumedColor[2] = (int)(assumptions->robot_color[2] * 255);

		if (inRange(pixel[0], assumedColor[0], 20) && inRange(pixel[1], assumedColor[1], 20) && inRange(pixel[2], assumedColor[2], 20))
			return true;
		
		return false;
	}	
};
