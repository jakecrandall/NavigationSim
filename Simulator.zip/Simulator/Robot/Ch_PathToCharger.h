#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>
#include <list>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;

#define HIST_LEN	20

class PathToCharger : public Ch_Interface {
public:
	Planner *plan;
	Mapper *map;
	list<double> recentPathCost;
	double distanceTraveled;
	chrono::steady_clock::time_point currentTime, laEmpieza;
	int timeCount;
	Point lastPos;

	PathToCharger(Mapper *_mapper, Planner *_planner, Mover *_mover, Assumptions *_assumptions) {
		map = _mapper;
		plan = _planner;
		distanceTraveled = 0.0;
		timeCount = 0;
		laEmpieza = chrono::steady_clock::now();
		lastPos.x = lastPos.y = -99999;
		currentStatus = true;
		nombre = "DesirablePath";
	}
	
	~PathToCharger() {
		//cout << "deleting PathToCharger" << endl;
	}
	
	bool evaluateAssertion() {
		if (plan->isStuck()) {
			return currentStatus;
		}

		// the path should exist
		bool statusHolder = false;
        if (plan->optPath.size() > 0) {
            // optPath[0] should be on the goal
            Point chrgr;
            chrgr.x = map->chargerPos[0];
            chrgr.y = map->chargerPos[1];
            if (veryNear(plan->optPath[0].p2, chrgr)) {
				statusHolder = true;
            }
        }

		// only update it every second
		currentTime = chrono::steady_clock::now();
		double elapsedTime = (chrono::duration_cast<chrono::microseconds> (currentTime - laEmpieza).count()) / 1000000.0;
		if (elapsedTime < timeCount) {
			return currentStatus;
		}

		timeCount ++;
		if (map->robotPos[0] > -9999) {
			if (lastPos.x > -9999) {	// don't update the first time
				Point cur;
				cur.x = map->robotPos[0];
				cur.y = map->robotPos[1];
				distanceTraveled += getDist(cur, lastPos);
			}
			lastPos.x = map->robotPos[0];
			lastPos.y = map->robotPos[1];
		}
		//cout << "time to update distanceTraveled: " << distanceTraveled << endl;
		if (statusHolder) {
			// the path length should be consistent and "low"
			recentPathCost.push_back(plan->currentDistancia + distanceTraveled);
			if (recentPathCost.size() > HIST_LEN) {
				recentPathCost.erase(recentPathCost.begin());

				// check that the stdev is small
				double stDev = distanceSD();
				//cout << stDev << ": " << plan->currentDistancia << ", " << distanceTraveled << " = " << (plan->currentDistancia + distanceTraveled) << endl;

				if (stDev > 20.0) {
					currentStatus = false;
				}
				else {
					currentStatus = true;
				}
			}
			else {
				//cout << plan->currentDistancia << ", " << distanceTraveled << " = " << (plan->currentDistancia + distanceTraveled) << endl;
				currentStatus = statusHolder;
			}
		}
		else {
			currentStatus = false;
		}

		return false;
	}

    bool veryNear(Point p1, Point p2) {
		if (getDist(p1, p2) <= 5.0) {
			return true;
		}
		return false;
	}

    double getDist(Point p1, Point p2) {
		double x = p1.x - p2.x;
		double y = p1.y - p2.y;
		return sqrt(x*x + y*y);
	}

	double distanceSD() {
		double mean = 0.0;
		for (list<double>::iterator iter = recentPathCost.begin(); iter != recentPathCost.end(); iter++) {
			mean += *iter;
		}
		mean /= recentPathCost.size();

		double sum = 0.0;
		for (list<double>::iterator iter = recentPathCost.begin(); iter != recentPathCost.end(); iter++) {
			sum += fabs(*iter - mean) * fabs(*iter - mean);
		}
		sum /= recentPathCost.size();
		sum = sqrt(sum);

		return sum;
	}
};
