#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>
#include <list>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;

// these are assumptions
#define MAX_SPEED		12.0
#define MAX_ROTATION	30

struct Pose {
	double x, y, theta;
	double tiempo;
};

struct Command {
	int direction;
	double rate;
	double tiempo;
};

class ExpectedRobotMovement : public Ch_Interface {
public:
	list<Pose> poseHistory;
	list<Command> commandHistory;
	list<double> distDiffs;
	Mapper *map;
	Mover *move;
	Assumptions *assumptions;
	chrono::steady_clock::time_point startTime;
	double ventana;
	double aveTraveled;
	
	ExpectedRobotMovement(Mapper *_mapper, Planner *_planner, Mover *_mover, Assumptions *_assumptions) {
		map = _mapper;
		move = _mover;
		assumptions = _assumptions;
		startTime = chrono::steady_clock::now();
		ventana = 5.0;
		aveTraveled = 10.0;
		currentStatus = true;
		nombre = "ExpectedRobotMovements";
	}
	
	~ExpectedRobotMovement() {
		//cout << "deleting ExpectedRobotMovements" << endl;
	}
	
/* 
Plan:
	see if the movement commands over the last N seconds resulted
	in the robot getting to the place we expected it to get to
*/
	bool evaluateAssertion() {
		if (!move->thetaEstimated)
			return currentStatus;

		// update the vectors
		chrono::steady_clock::time_point curTime = chrono::steady_clock::now();
		Pose p;

		p.x = map->robotPos[0];
		p.y = map->robotPos[1];
		p.theta = move->theta;
		p.tiempo = (chrono::duration_cast<chrono::microseconds> (curTime - startTime).count()) / 1000000.0;
		poseHistory.push_back(p);

		Command c;
		readActuators(&(c.direction), &(c.rate));
		c.tiempo = p.tiempo;
		commandHistory.push_back(c);

		pruneLists(ventana, p.tiempo);

		// simulate movements in the absense of obstacles
		simulateMovements();

		double sum = 0;
		for (list<double>::iterator iter = distDiffs.begin(); iter != distDiffs.end(); iter++) {
			sum += *iter;
		}

		if (distDiffs.size() > 20) {
			//cout << (sum / distDiffs.size()) << endl;

			if ((sum / distDiffs.size()) > 0.18)
				currentStatus = false;
			else
				currentStatus = true;
		}

		return currentStatus;
	}

	void simulateMovements() {
		Pose currentPose;

		list<Pose>::iterator poseIterator = poseHistory.begin();
		list<Command>::iterator commandIterator = commandHistory.begin();
		currentPose.x = poseIterator->x;
		currentPose.y = poseIterator->y;
		currentPose.theta = poseIterator->theta;
		currentPose.tiempo = poseIterator->tiempo;
		int dir = commandIterator->direction;
		double rate = commandIterator->rate;
		double timeElapsed;
		++poseIterator;
		++commandIterator;

		double moveDistance, dx, dy, dRot;
		double estDistTraveled = 0.0;
		while (poseIterator != poseHistory.end()) {
			timeElapsed = poseIterator->tiempo - currentPose.tiempo;
			//cout << "timeElapsed: " << timeElapsed << endl;

			if (dir == 0) {
				moveDistance = assumptions->max_speed * 2.0 * rate * timeElapsed;
				dx = moveDistance * cos(currentPose.theta * M_PI / 180.0);
				dy = moveDistance * sin(currentPose.theta * M_PI / 180.0);
				currentPose.x += dx;
				currentPose.y += dy;

				estDistTraveled += moveDistance;
			}
			else {
				dRot = assumptions->max_spin * rate * timeElapsed * dir;
				currentPose.theta += dRot;
			}

			currentPose.tiempo = poseIterator->tiempo;
			dir = commandIterator->direction;
			rate = commandIterator->rate;

			++commandIterator;
			++poseIterator;
		}

		double x = currentPose.x - map->robotPos[0];
		double y = currentPose.y - map->robotPos[1];
		double dist = sqrt(x*x + y*y);
		
		double _lambda = 0.995;
		aveTraveled = _lambda * aveTraveled + (1.0 - _lambda) * estDistTraveled;

		//cout << "diffDistance: " << dist << " (" << aveTraveled << ")" << endl;

		if (estDistTraveled > aveTraveled) {
			distDiffs.push_back(dist / estDistTraveled);
			while (distDiffs.size() > 50) {//poseHistory.size()) {
				distDiffs.erase(distDiffs.begin());
			}
		}
		
		//cout << "At time " << currentPose.theta << " (" << poseHistory.size() << ")" << endl;
		//cout << "  Estimated pose: " << currentPose.x << ", " << currentPose.y << ", " << currentPose.theta << endl;
		//cout << "  Actual pose: " << map->robotPos[0] << ", " << map->robotPos[1] << ", " << move->theta << endl;
	}

	void pruneLists(double _ventana, double _curTime) {
		while (poseHistory.begin()->tiempo < (_curTime - _ventana)) {
			poseHistory.erase(poseHistory.begin());
		}

		while (commandHistory.begin()->tiempo < (_curTime - _ventana)) {
			commandHistory.erase(commandHistory.begin());
		}
	}
	
	void readActuators(int *direction, double *rate) {
		string line;
		string fname = "../MundoVerdadero/State/robotactuators_0.txt";
		ifstream ainput(fname);
		if (!ainput.fail()) {
			while (!ainput.eof()) {
				if (!(ainput >> line)) {
					break;
				}
				if (line == "rate") {
					ainput >> *rate;
				}
				else if (line == "direction") {
					ainput >> *direction;
				}
			}
		}
		else {
			cout << "robotactuators file not found: " << fname << endl;
		}
		
		ainput.close();
	}
	
	double distance(double x, double y) {
		return sqrt(x*x + y*y);
	}
};
