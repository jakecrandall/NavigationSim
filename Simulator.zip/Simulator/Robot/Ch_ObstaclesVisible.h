#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>
#include <list>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;

#define NUM_FRAMES	50

struct Command2 {
	int direction;
	double rate;
};

class ObstaclesVisible : public Ch_Interface {
public:
	Mapper *map;
	Mover *move;
	Assumptions *assumptions;
	list<Point> rPosLog;
	list<Command2> actuatorLog;

	ObstaclesVisible(Mapper *_mapper, Planner *_planner, Mover *_mover, Assumptions *_assumptions) {
		map = _mapper;
		move = _mover;
		assumptions = _assumptions;
		currentStatus = true;
		nombre = "ObstaclesVisible";
	}
	
	~ObstaclesVisible() {
		//cout << "deleting ObstaclesVisible" << endl;
	}
	
	bool evaluateAssertion() {

		// keep track of the robot's positions over the last N frames
		Point p;
		p.x = map->robotPos[0];
		p.y = map->robotPos[1];
		rPosLog.push_back(p);
		while (rPosLog.size() > NUM_FRAMES)
			rPosLog.erase(rPosLog.begin());

		// keep track of the commands given to the robot over the last N frames
		Command2 c;
		c.direction = move->direction;
		c.rate = move->rate;
		actuatorLog.push_back(c);
		while (actuatorLog.size() > NUM_FRAMES)
			actuatorLog.erase(actuatorLog.begin());

		if (actuatorLog.size() < NUM_FRAMES)
			return currentStatus;

		// if the robot is trying to move, isn't moving, and there are no visible obstacles nearby
		int moveAttemptCount = 0;
		for (list<Command2>::iterator iter = actuatorLog.begin(); iter != actuatorLog.end(); iter++) {
			if ((iter->direction == 0) && (iter->rate > 0.1))
				moveAttemptCount ++;
		}
		double moveAttemptRate = (double)moveAttemptCount / actuatorLog.size();
		//cout << "moveAttemptRate: " << moveAttemptRate << endl;

		if ((moveAttemptRate < 0.4) || obstaclesNearby(map->robotPos[0], map->robotPos[1])) {
			// don't change the status
			//currentStatus = true;
		}
		else {
			// see if the robot is moving
			double maxDist = 0.0, dist;
			for (list<Point>::iterator iter = rPosLog.begin(); iter != rPosLog.end(); iter++) {
				dist = getDist(*(rPosLog.begin()), *iter);
				if (dist > maxDist)
					maxDist = dist;
			}
			//cout << "maxDist: " << maxDist << endl;

			if (maxDist > 2.0) 
				currentStatus = true;
			else
				currentStatus = false;
		}

		//cout << "currentStatus: " << (int)currentStatus << endl;

		return currentStatus;
	}

	double getDist(Point p1, Point p2) {
		double x = p1.x - p2.x;
		double y = p1.y - p2.y;
		return sqrt(x*x + y*y);
	}

	bool obstaclesNearby(int x, int y) {
		int neighborhood = 0;
		for (int i = x - neighborhood; i <= x+neighborhood; i++) {
			if ((x < 0) || (x >= map->imgwidth))
				continue;
			for (int j = y - neighborhood; j <= y+neighborhood; j++) {
				if ((y < 0) || (y >= map->imgheight))
					continue;
				if (map->obst[i][j]) {
					//cout << "obstacle nearby" << endl;
					return true;
				}
			}
		}

		return false;
	}
};
