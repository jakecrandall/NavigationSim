#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>
#include <list>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;

class ConsistentMap : public Ch_Interface {
public:
	Mapper *map;
	Mover *move;
	Assumptions *assumptions;
	list<Point> robotPos;
	double runningSD;
	int minSamples, cutOff;

	int currentIndex;

	ConsistentMap(Mapper *_mapper, Planner *_planner, Mover *_mover, Assumptions *_assumptions) {
		map = _mapper;
		move = _mover;
		assumptions = _assumptions;
		runningSD = 0.0;
		minSamples = 10;
		cutOff = 5;
		currentStatus = true;
		nombre = "ConsistentMap";
	}
	
	~ConsistentMap() {
		//cout << "deleting ConsistentMap" << endl;
	}
	
	bool evaluateAssertion() {

		// see how much the robot's position estimate varies when it is sitting still
		if (move->direction == 0) {
			robotPos.clear();
		}
		else {
			Point p;
			p.x = map->robotPos[0];
			p.y = map->robotPos[1];
			robotPos.push_back(p);

			// compute standard deviation
			if (robotPos.size() >= minSamples) {
				double rPosSD = getRobotPosSD();
				double lambda = 0.95;
				runningSD = lambda * runningSD + (1 - lambda) * rPosSD;
				//cout << rPosSD << " -> " << runningSD << endl;

			}
		}

		// see how much the charger's position estimate varies
		if (runningSD >= 0.09)
			currentStatus = false;
		else
			currentStatus = true;

		return currentStatus;
	}

	double getRobotPosSD() {
		Point mean;
		mean.x = mean.y = 0.0;
		int count = 0;
		for (list<Point>::iterator iter = robotPos.begin(); iter != robotPos.end(); iter++) {
			if (count >= cutOff) {
				mean.x += iter->x;
				mean.y += iter->y;
			}
			count ++;
		}
		mean.x /= robotPos.size() - cutOff;
		mean.y /= robotPos.size() - cutOff;

		Point sum;
		sum.x = sum.y = 0;
		count = 0;
		for (list<Point>::iterator iter = robotPos.begin(); iter != robotPos.end(); iter++) {
			if (count >= cutOff) {
				sum.x += fabs(iter->x - mean.x) * fabs(iter->x - mean.x);
				sum.y += fabs(iter->y - mean.y) * fabs(iter->y - mean.y);
			}
			count ++;
		}
		sum.x /= robotPos.size() - cutOff;
		sum.y /= robotPos.size() - cutOff;
		sum.x = sqrt(sum.x);
		sum.y = sqrt(sum.y);

		return (sum.x + sum.y) / 2.0;
	}
};
