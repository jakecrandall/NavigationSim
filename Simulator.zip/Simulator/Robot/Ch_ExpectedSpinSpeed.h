#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <chrono>

#include "Gen_Mapper.h"
#include "Gen_Planner.h"
#include "Gen_Mover.h"

using namespace std;

class ExpectedSpinSpeed : public Ch_Interface {
public:
	Mapper *map;
	Mover *move;
	Assumptions *assumptions;
	double observedTheta, startTheta, estimatedDeltaTheta;
	int curDirection;
	Point startEstimate;
	bool updatedSinceStart, justUpdated, lastUpdated;
	double thetaError;
	int numExperiments;


	//int experimentCount;
	bool inExperiment;
	double rate, epochTime;
	int rateCount;
	chrono::steady_clock::time_point nuevoTime, epochStart;

	ExpectedSpinSpeed(Mapper *_mapper, Planner *_planner, Mover *_mover, Assumptions *_assumptions) {
		map = _mapper;
		move = _mover;
		assumptions = _assumptions;
		curDirection = -99999;
		observedTheta = thetaError = 0.0;
		numExperiments = 0;
		inExperiment = false;
		updatedSinceStart = false;
		currentStatus = true;
		nombre = "ExpectedSpinSpeed";
	}
	
	~ExpectedSpinSpeed() {
		//cout << "deleting ExpectedSpinSpeed" << endl;
	}
	
	bool evaluateAssertion() {

		updateObservedTheta();

		//if (curDirection != move->direction) {
		//	cout << "direction change: " << move->direction << endl;
		//}

		if (move->direction != 0) {
			if ((curDirection == 0) && !updatedSinceStart) {
				if (inExperiment) {
					//cout << "\tdidn't conclude the experiment" << endl;
					double dx =  map->robotPos[0] - startEstimate.x;
					double dy =  map->robotPos[1] - startEstimate.y;
					//cout << "\tdx: " << dx << "; dy: " << dy << endl;
					double extent = fabs(dx);
					if (fabs(dy) > extent)
						extent = fabs(dy);
					extent /= 2.5;
					if (extent > 1.0)
						extent = 1.0;
					//cout << "\textent: " << (extent*extent) << endl;
					if (extent > 0) {
						observedTheta = atan2(dy, dx) * 180.0 / M_PI;
						//cout << "  observedTheta (short): " << observedTheta << endl;
						updateThetaError(extent*extent);
						lastUpdated = true;
					}
				}
				// the robot starts to turn; if we have a recent reading of theta, begin the experiment
				if (lastUpdated) {
					//cout << "Starting an experiment -> rotating from " << observedTheta << endl;

					inExperiment = true;
					//experimentCount = 0;
					startTheta = observedTheta;
					//cout << "startTheta: " << startTheta << endl;
					epochStart = chrono::steady_clock::now();
					rate = 0.0;
					rateCount = 0;
				}
			}
			else if (curDirection != move->direction) {
				//cout << "\tdirection change" << endl;
				//if ((curDirection == 0) && inExperiment) {
				//	cout << "\tCan I do a straight test?" << endl;
				//}
				
				if (inExperiment) {
					// terminate the experiment; we're just going back and forth
					//cout << "\tterminating the experiment" << endl;
					inExperiment = false;
				}
			}
			else {
				// update estimate of theta
				rate += move->rate;
				rateCount ++;
				nuevoTime = chrono::steady_clock::now();
				epochTime = (chrono::duration_cast<chrono::microseconds> (nuevoTime - epochStart).count()) / 1000000.0;

				estimatedDeltaTheta = move->direction * (rate / rateCount) * assumptions->max_spin * epochTime;

				//cout << "estimatedDeltaTheta: " << estimatedDeltaTheta << endl;
			}
		}
		else {
			if (inExperiment) {
				//cout << "epochTime: " << epochTime << endl;
				//experimentCount ++;
				//cout << "experimentCount: " << experimentCount << endl;
				if (epochTime < 0.75) {
					inExperiment = false;
					//cout << "\tepoch was too short (" << epochTime << ")" << endl;
				}
				else if (updatedSinceStart) {
					updateThetaError(1.0);
					//experimentCount = 0;
					inExperiment = false;
				}
				else {
					//cout << "\tgoing straight in experiment" << endl;
				}
			}
			else {
				//cout << "going straight not in experiment" << endl;
			}
		}

		curDirection = move->direction;

		return currentStatus;
	}

	void updateThetaError(double extent2Update) {
		//cout << "estimatedDeltaTheta: " << estimatedDeltaTheta << endl;
		double projectedTheta = startTheta + estimatedDeltaTheta;
		//cout << "\tprojected: " << projectedTheta << " vs observed: " << observedTheta << endl;
		while ((projectedTheta - observedTheta) > 180.0) {
			projectedTheta -= 360.0;
		}
		while ((projectedTheta - observedTheta) < -180.0) {
			projectedTheta += 360.0;
		}
		//cout << "\trate: " << (rate / rateCount) << " (" << rateCount << ")" << endl;
		//cout << "\tepochTime: " << epochTime << endl;
		double diff = fabs(projectedTheta - observedTheta) / epochTime;

		numExperiments++;
		if (numExperiments > 1) {
			double lambda = 1.0 / (numExperiments-1);
			if (lambda < 0.2)
				lambda = 0.2;
			lambda *= extent2Update;
			thetaError = (1 - lambda) * thetaError + lambda * diff;
			//cout << "\tprojected: " << projectedTheta << " vs observed: " << observedTheta << endl;
			//cout << "\tmeasurement outcome: diff = " << diff << "; thetaError = " << thetaError << " (" << extent2Update << ")" << endl;
		}
		if (thetaError > 3.5)
			currentStatus = false;
		else
			currentStatus = true;
	}

	void updateObservedTheta() {
		//cout << "move direction: " << move->direction << endl;
		//cout << "curDirection: " << curDirection << endl;
		lastUpdated = justUpdated;
		justUpdated = false;
		if (move->direction == 0) {
			if (curDirection != 0) {
				startEstimate.x = map->robotPos[0];
				startEstimate.y = map->robotPos[1];
				//updatedSinceStart = false;
				//cout << "startEstimate: (" << startEstimate.x << ", " << startEstimate.y << ")" << endl;
			}
			else {
				double dx =  map->robotPos[0] - startEstimate.x;
				double dy =  map->robotPos[1] - startEstimate.y;
				//cout << "dx: " << dx << "; dy: " << dy << endl;

				if ((fabs(dx) > 2.5) || (fabs(dy) > 2.5)) {
					observedTheta = atan2(dy, dx) * 180.0 / M_PI;
					//cout << "  observedTheta: " << observedTheta << endl;
					updatedSinceStart = true;
					justUpdated = true;
				}
			}
		}
		else {
			updatedSinceStart = false;
		}
	}
};
