import java.awt.*;
import java.util.*;
import java.awt.event.*;
import java.lang.*;
import java.io.*;
import java.net.*;
import javax.swing.*;
import java.math.*;
import java.text.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.JFrame;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


class Obstacle {
	double sx, sy, ex, ey;
	double rd, gn, bl;
	int ID;
	boolean updated;

	public Obstacle(String str) {
		//System.out.println("new Obstacle: " + str);
		StringTokenizer st = new StringTokenizer(str, " ");
		ID = Integer.parseInt(st.nextToken());
		sx = Double.parseDouble(st.nextToken());
		sy = Double.parseDouble(st.nextToken());
		ex = Double.parseDouble(st.nextToken());
		ey = Double.parseDouble(st.nextToken());
		rd = Double.parseDouble(st.nextToken());
		gn = Double.parseDouble(st.nextToken());
		bl = Double.parseDouble(st.nextToken());
		updated = true;
	}
	
	public void updateIt(String str) {
		StringTokenizer st = new StringTokenizer(str, " ");
		ID = Integer.parseInt(st.nextToken());
		sx = Double.parseDouble(st.nextToken());
		sy = Double.parseDouble(st.nextToken());
		ex = Double.parseDouble(st.nextToken());
		ey = Double.parseDouble(st.nextToken());
		rd = Double.parseDouble(st.nextToken());
		gn = Double.parseDouble(st.nextToken());
		bl = Double.parseDouble(st.nextToken());
		updated = true;
	}
}

class Robot {
	double x, y;
	double theta;
	double width, height;
	double rd, gn, bl;
	double speed, spin, bias;
	int ID, poder;
	boolean updated;
	boolean isCharging;
	
	public Robot(String str) {
		//System.out.println("new Robot: " + str);
		StringTokenizer st = new StringTokenizer(str, " ");
		ID = Integer.parseInt(st.nextToken());
		x = Double.parseDouble(st.nextToken());
		y = Double.parseDouble(st.nextToken());
		theta = Double.parseDouble(st.nextToken());
		width = Double.parseDouble(st.nextToken());
		height = Double.parseDouble(st.nextToken());
		speed = Double.parseDouble(st.nextToken());
		spin = Double.parseDouble(st.nextToken());
		bias = Double.parseDouble(st.nextToken());
		rd = Double.parseDouble(st.nextToken());
		gn = Double.parseDouble(st.nextToken());
		bl = Double.parseDouble(st.nextToken());
		poder = Integer.parseInt(st.nextToken());
		updated = true;

		isCharging = false;
	}
	
	public void updateIt(String str) {
		StringTokenizer st = new StringTokenizer(str, " ");
		ID = Integer.parseInt(st.nextToken());
		x = Double.parseDouble(st.nextToken());
		y = Double.parseDouble(st.nextToken());
		theta = Double.parseDouble(st.nextToken());
		width = Double.parseDouble(st.nextToken());
		height = Double.parseDouble(st.nextToken());
		speed = Double.parseDouble(st.nextToken());
		spin = Double.parseDouble(st.nextToken());
		bias = Double.parseDouble(st.nextToken());
		rd = Double.parseDouble(st.nextToken());
		gn = Double.parseDouble(st.nextToken());
		bl = Double.parseDouble(st.nextToken());
		poder = Integer.parseInt(st.nextToken());
		updated = true;
	}
}

class Charger {
	double x, y;
	double width, height;
	double rd, gn, bl;
	int ID;
	boolean updated;
	
	public Charger(String str) {
		//System.out.println("new Charger: " + str);
		StringTokenizer st = new StringTokenizer(str, " ");
		ID = Integer.parseInt(st.nextToken());
		x = Double.parseDouble(st.nextToken());
		y = Double.parseDouble(st.nextToken());
		width = Double.parseDouble(st.nextToken());
		height = Double.parseDouble(st.nextToken());
		rd = Double.parseDouble(st.nextToken());
		gn = Double.parseDouble(st.nextToken());
		bl = Double.parseDouble(st.nextToken());
		updated = true;
	}
	
	public void updateIt(String str) {
		StringTokenizer st = new StringTokenizer(str, " ");
		ID = Integer.parseInt(st.nextToken());
		x = Double.parseDouble(st.nextToken());
		y = Double.parseDouble(st.nextToken());
		width = Double.parseDouble(st.nextToken());
		height = Double.parseDouble(st.nextToken());
		rd = Double.parseDouble(st.nextToken());
		gn = Double.parseDouble(st.nextToken());
		bl = Double.parseDouble(st.nextToken());
		updated = true;
	}
}

// CameraSensor 0 50 50 50 0 0 -1 45 45 200 200 1 1 1 1
class CameraSpecs {
	double x, y, z;
	double ox, oy, oz;
	double viewx, viewy;
	int resx, resy;
	double fr, fg, fb;
	int ID, poder;
	double raynoise, distortion;
	boolean updated;
	
	public CameraSpecs(String str) {
		//System.out.println("new Charger: " + str);
		StringTokenizer st = new StringTokenizer(str, " ");
		ID = Integer.parseInt(st.nextToken());
		x = Double.parseDouble(st.nextToken());
		y = Double.parseDouble(st.nextToken());
		z = Double.parseDouble(st.nextToken());
		ox = Double.parseDouble(st.nextToken());
		oy = Double.parseDouble(st.nextToken());
		oz = Double.parseDouble(st.nextToken());
		viewx = Double.parseDouble(st.nextToken());
		viewy = Double.parseDouble(st.nextToken());
		resx = Integer.parseInt(st.nextToken());
		resy = Integer.parseInt(st.nextToken());
		fr = Double.parseDouble(st.nextToken());
		fg = Double.parseDouble(st.nextToken());
		fb = Double.parseDouble(st.nextToken());
		raynoise = Double.parseDouble(st.nextToken());
		distortion = Double.parseDouble(st.nextToken());
		poder = Integer.parseInt(st.nextToken());
		updated = true;
	}
	
	public void updateIt(String str) {
		StringTokenizer st = new StringTokenizer(str, " ");
		ID = Integer.parseInt(st.nextToken());
		x = Double.parseDouble(st.nextToken());
		y = Double.parseDouble(st.nextToken());
		z = Double.parseDouble(st.nextToken());
		ox = Double.parseDouble(st.nextToken());
		oy = Double.parseDouble(st.nextToken());
		oz = Double.parseDouble(st.nextToken());
		viewx = Double.parseDouble(st.nextToken());
		viewy = Double.parseDouble(st.nextToken());
		resx = Integer.parseInt(st.nextToken());
		resy = Integer.parseInt(st.nextToken());
		fr = Double.parseDouble(st.nextToken());
		fg = Double.parseDouble(st.nextToken());
		fb = Double.parseDouble(st.nextToken());
		raynoise = Double.parseDouble(st.nextToken());
		distortion = Double.parseDouble(st.nextToken());
		poder = Integer.parseInt(st.nextToken());
		updated = true;
	}
}

class CameraSensor {
	int width, height;
	int[][][] img;
	
	public CameraSensor() {
		String file = "../MundoVerdadero/State/cameraimg_0.txt";
		String str;
		
		try{
			BufferedReader reader = new BufferedReader(new FileReader(file));
			
			str = reader.readLine();
			str = reader.readLine();
			width = Integer.parseInt(str);
			str = reader.readLine();
			height = Integer.parseInt(str);
			img = new int[width][height][3];
			for (int yy = 0; yy < height; yy++) {
				for (int xx = 0; xx < width; xx++) {
					str = reader.readLine();
					StringTokenizer st = new StringTokenizer(str, " ");
					img[xx][yy][0] = Integer.parseInt(st.nextToken());
					img[xx][yy][1] = Integer.parseInt(st.nextToken());
					img[xx][yy][2] = Integer.parseInt(st.nextToken());
				}
			}
			
			reader.close();
		}
		catch (IOException e) {
			System.out.println(e);
		}
	}
}

class ObstacleMap {
	int width, height;
	double[] robotPos = new double[2];
	double[] chargerPos = new double[2];
	int[][] obst;
	
	public ObstacleMap() {
		String file = "../Robot/output/mapper_0.txt";
		String str;
		
		try{
			BufferedReader reader = new BufferedReader(new FileReader(file));
			
			str = reader.readLine();
			robotPos[0] = Double.parseDouble(str);
			str = reader.readLine();
			robotPos[1] = Double.parseDouble(str);
			str = reader.readLine();
			chargerPos[0] = Double.parseDouble(str);
			str = reader.readLine();
			chargerPos[1] = Double.parseDouble(str);
			
			str = reader.readLine();
			width = Integer.parseInt(str);
			str = reader.readLine();
			height = Integer.parseInt(str);
			obst = new int[width][height];
			for (int yy = 0; yy < height; yy++) {
				str = reader.readLine();
				for (int xx = 0; xx < width; xx++) {
					if (str.charAt(xx) == '1')
						obst[xx][yy] = 1;
					else
						obst[xx][yy] = 0;
				}
			}
			
			reader.close();
		}
		catch (IOException e) {
			System.out.println(e);
		}
	}
}

class myCanvas extends JComponent {
	Vector<Obstacle> obstacles = new Vector<Obstacle>();
	Vector<Robot> robots = new Vector<Robot>();
	Vector<Charger> chargers = new Vector<Charger>();
	Vector<CameraSpecs> cameraspecs = new Vector<CameraSpecs>();
	boolean simulationOn = false;
	int keyFocusIndex = -1;
	Point mousePunto;
	String popMsg;

    public static final Color myRed = new Color(200, 0, 0);
	public static final Color myOrange = new Color(255, 140, 0);
    public static final Color myBlue = new Color(0, 0, 200);
	public static final Color myBlack = new Color(0, 0, 0);
	public static final Color myGreen = new Color(0, 200, 0);

	// AssertionCheckers acheckers = new AssertionCheckers();

	int paintCount = 0;

	int screenX = 0, screenY = 0;

    public myCanvas() {
        MyThread thread = new MyThread();
        thread.start();

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            System.out.println(e);
        }
    }

	public void updateScreenPosition(int x, int y) {
		screenX = x;
		screenY = y;
		//System.out.println("Screen: " + screenX + ", " + screenY);
	}

    public class MyThread extends Thread {
		public void updateRobots(String str) {
			// see if this robot already exists
			boolean found = false;
		
			StringTokenizer st = new StringTokenizer(str, " ");
			int id = Integer.parseInt(st.nextToken());
			//System.out.println("Robot ID: " + id);
			for (int i = 0; i < robots.size(); i++) {
				if (id == robots.get(i).ID) {
					robots.get(i).updateIt(str);
					found = true;
					break;
				}
			}
		
			if (!found) {
				System.out.println("We have a new robot");
				robots.add(new Robot(str));
			}
		}
		
		public void updateObstacles(String str) {
			// see if this obstacle already exists
			boolean found = false;
		
			StringTokenizer st = new StringTokenizer(str, " ");
			int id = Integer.parseInt(st.nextToken());
			//System.out.println("Obstacle ID: " + id);
			for (int i = 0; i < obstacles.size(); i++) {
				if (id == obstacles.get(i).ID) {
					obstacles.get(i).updateIt(str);
					found = true;
					break;
				}
			}
		
			if (!found) {
				System.out.println("We have a new obstacle");
				obstacles.add(new Obstacle(str));
			}
		}
		
		public void updateChargers(String str) {
			// see if this charger already exists
			boolean found = false;
		
			StringTokenizer st = new StringTokenizer(str, " ");
			int id = Integer.parseInt(st.nextToken());
			//System.out.println("Charger ID: " + id);
			for (int i = 0; i < chargers.size(); i++) {
				if (id == chargers.get(i).ID) {
					chargers.get(i).updateIt(str);
					found = true;
					break;
				}
			}
		
			if (!found) {
				System.out.println("We have a new charger");
				chargers.add(new Charger(str));
			}
		}

		public void updateCameras(String str) {
			// see if this camera already exists
			boolean found = false;
		
			StringTokenizer st = new StringTokenizer(str, " ");
			int id = Integer.parseInt(st.nextToken());
			//System.out.println("Charger ID: " + id);
			for (int i = 0; i < cameraspecs.size(); i++) {
				if (id == cameraspecs.get(i).ID) {
					cameraspecs.get(i).updateIt(str);
					found = true;
					break;
				}
			}
		
			if (!found) {
				System.out.println("We have a new charger");
				cameraspecs.add(new CameraSpecs(str));
			}
		}
	
		public void updateThings() {
			// Set each object to not having been updated
			for (int i = 0; i < robots.size(); i++) {
				robots.get(i).updated = false;
			}
			for (int i = 0; i < obstacles.size(); i++) {
				obstacles.get(i).updated = false;
			}
			for (int i = 0; i < chargers.size(); i++) {
				chargers.get(i).updated = false;
			}
		
			try {
				// update objects by reading status.txt
				String file = "../MundoVerdadero/State/status.txt";
				String str;
				BufferedReader reader = new BufferedReader(new FileReader(file));
				
				while (((str=reader.readLine()) != null) && (str.length()!=0)) {
					// see what kind of object it is
					StringTokenizer st = new StringTokenizer(str, " ");
					String str2 = st.nextToken();
					switch (str2) {
						case "Robot": updateRobots(st.nextToken("")); break;
						case "Obstacle": updateObstacles(st.nextToken("")); break;
						case "Charger": updateChargers(st.nextToken("")); break;
						case "CameraSensor": updateCameras(st.nextToken("")); break;
						default: System.out.println("Don't recognize object " + str2); break;
					}
				}
				
				reader.close();
			}
			catch (IOException e) {
				System.out.println(e);
			}
			
			// remove objects that have not been updated
			for (int i = 0; i < robots.size(); i++) {
				if (!(robots.get(i).updated)) {
					System.out.println("removing robot " + robots.get(i).ID);
					robots.remove(i);
					i--;
				}
			}
			for (int i = 0; i < obstacles.size(); i++) {
				if (!(obstacles.get(i).updated)) {
					System.out.println("removing obstacle " + obstacles.get(i).ID);
					obstacles.remove(i);
					i--;
				}
			}
			for (int i = 0; i < chargers.size(); i++) {
				if (!(chargers.get(i).updated)) {
					System.out.println("removing charger " + chargers.get(i).ID);
					chargers.remove(i);
					i--;
				}
			}
			
			// see if the simulation is on or off
			try {
				// update objects by reading status.txt
				String file = "../MundoVerdadero/State/sim.txt";
				String str;
				BufferedReader reader = new BufferedReader(new FileReader(file));
				
				str = reader.readLine();
				//System.out.println("the simulation is " + str);
				if (str.equals("on"))
					simulationOn = true;
				else
					simulationOn = false;
				
				reader.close();
			}
			catch (IOException e) {
				System.out.println(e);
			}

			try {
				// find out which robot is being controlled
				String file = "../MundoVerdadero/State/keyFocusIndex.txt";
				String str;
				BufferedReader reader = new BufferedReader(new FileReader(file));
				str = reader.readLine();
				keyFocusIndex = Integer.parseInt(str);
				reader.close();
			}
			catch (IOException e) {
				System.out.println(e);
			}

			// get an update on charging
			try {
				for (int i = 0; i < robots.size(); i++) {
					String file = "../MundoVerdadero/State/charging_" + i + ".txt";
					BufferedReader reader = new BufferedReader(new FileReader(file));
					if (reader.readLine().equals("0")) {
						robots.get(i).isCharging = false;
					}
					else {
						robots.get(i).isCharging = true;
					}

					reader.close();
				}
			}
			catch (IOException e) {
				System.out.println(e);
			}
		
		}
	
        public void run() {
            try {
                // repeatedly read status.txt and display
				while (true) {
					updateThings();
                    repaint();
                    Thread.sleep(100);
                }
            }
            catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }

    public void paint(Graphics g) {
		paintWorldFrame(g, 0, 0);
		paintCameraSensor(g, 310, 0);
		paintRobotSpecs(g, 310+290, 0);
    }

	public void paintRobotSpecs(Graphics g, int cx, int cy) {
		if (robots.size() == 0)
			return;

		int componentWidth = 251, componentHeight = 310;

		g.setColor(new Color(200, 200, 200));
		g.fillRect(cx, cy, componentWidth, componentHeight);
			
		g.setColor(new Color(230, 230, 230));
		g.fillRect(cx + 5, cy + 5, componentWidth-10, componentHeight-10);

		int yspace = 80;
		for (int i = 0; i < robots.size(); i++) {
			g.setColor(new Color(150, 150, 150));
			g.drawRoundRect(10+cx, 7 + cy + (yspace * i), 63, 19, 10, 10);

			g.setFont(new Font("Arial", Font.PLAIN, 16));
			if (robots.get(i).poder == 1)
				g.setColor(myBlack);
			else
				g.setColor(new Color(150, 150, 150));
			String str = "Robot " + i;
			g.drawString(str, 13 + cx, 22 + cy + (yspace * i));
			if (i == keyFocusIndex) {
				g.setColor(myOrange);
				g.fillRect(cx + 80, cy + 13 + (yspace * i), 7, 7);
			}
			if (robots.get(i).isCharging) {
				g.setColor(myBlack);
				int xmid = cx + componentWidth - 55 + 12;
				int ymid = cy + 10 + (yspace * i);
				g.drawRect(xmid - 12, ymid, 24, 13);
				g.fillRect(xmid + 12, ymid+4, 2, 5);
				int[] x = new int[7];
				int[] y = new int[7];
				x[0] = xmid+3; x[1] = xmid-5; x[2] = xmid; x[3] = xmid-2; x[4] = xmid+5; x[5] = xmid; x[6] = xmid+3;
				y[0] = ymid-1; y[1] = ymid+8; y[2] = ymid+8; y[3] = ymid+14; y[4] = ymid+6; y[5] = ymid+6; y[6] = ymid-1;
				g.fillPolygon(x, y, 7);
			}
	
			// pose, size, max_speed, max_spin, bias, color
			g.setFont(new Font("Arial", Font.PLAIN, 12));
			g.setColor(myBlue);
			str = "pose";
			g.drawString(str, 10 + cx, 39 + cy + (yspace * i));

			g.setColor(myBlack);
			
			str = "" + String.format("%1$,.1f", robots.get(i).x) + ", " + String.format("%1$,.1f", robots.get(i).y) + ", " + String.format("%1$,.1f", robots.get(i).theta);
			//str = "" + robots.get(i).x + ", " + robots.get(i).y + ", " + robots.get(i).theta;
			g.drawString(str, 49 + cx, 39 + cy + (yspace * i));

			g.setFont(new Font("Arial", Font.PLAIN, 12));
			g.setColor(myBlue);
			str = "size";
			g.drawString(str, 10 + cx, 55 + cy + (yspace * i));

			g.setColor(myBlack);
			str = "" + robots.get(i).width + " x " + robots.get(i).height;
			g.drawString(str, 49 + cx, 55 + cy + (yspace * i));

			g.setFont(new Font("Arial", Font.PLAIN, 12));
			g.setColor(myBlue);
			str = "color";
			g.drawString(str, 10 + cx, 71 + cy + (yspace * i));

			g.setColor(myBlack);
			str = "" + robots.get(i).rd + ", " + robots.get(i).gn + ", " + robots.get(i).bl;
			g.drawString(str, 49 + cx, 71 + cy + (yspace * i));

			g.setFont(new Font("Arial", Font.PLAIN, 12));
			g.setColor(myBlue);
			str = "speed";
			g.drawString(str, 160 + cx, 39 + cy + (yspace * i));

			g.setColor(myBlack);
			str = "" + robots.get(i).speed;
			g.drawString(str, 200 + cx, 39 + cy + (yspace * i));

			g.setFont(new Font("Arial", Font.PLAIN, 12));
			g.setColor(myBlue);
			str = "spin";
			g.drawString(str, 160 + cx, 55 + cy + (yspace * i));

			g.setColor(myBlack);
			str = "" + robots.get(i).spin;
			g.drawString(str, 200 + cx, 55 + cy + (yspace * i));

			g.setFont(new Font("Arial", Font.PLAIN, 12));
			g.setColor(myBlue);
			str = "bias";
			g.drawString(str, 160 + cx, 71 + cy + (yspace * i));

			g.setColor(myBlack);
			str = "" + robots.get(i).bias;
			g.drawString(str, 200 + cx, 71 + cy + (yspace * i));
		}
	}

	public void paintCameraSensor(Graphics g, int cx, int cy) {
		if (cameraspecs.size() == 0)
			return;

		int componentWidth = 290, componentHeight = 310;

        g.setColor(new Color(200, 200, 200));
        g.fillRect(cx, cy, componentWidth, componentHeight);
        
		g.setColor(new Color(230, 230, 230));
        g.fillRect(cx + 5, cy + 5, componentWidth-10, componentHeight-10);

		g.setFont(new Font("Arial", Font.PLAIN, 16));
		if (cameraspecs.get(0).poder == 1)
			g.setColor(myBlack);
		else
			g.setColor(new Color(150, 150, 150));
		String str = "Camera Sensor";
		g.drawString(str, 10 + cx, 22 + cy);

		// location
		g.setFont(new Font("Arial", Font.PLAIN, 12));
		g.setColor(myBlue);
		str = "location";
		g.drawString(str, 10 + cx, 37 + cy);

		g.setColor(myBlack);
		str = "" + cameraspecs.get(0).x + ", " + cameraspecs.get(0).y + ", " + cameraspecs.get(0).z;
		g.drawString(str, 74 + cx, 37 + cy);

		// orientation
		g.setFont(new Font("Arial", Font.PLAIN, 12));
		g.setColor(myBlue);
		str = "orientation";
		g.drawString(str, 10 + cx, 53 + cy);

		g.setColor(myBlack);
		str = "" + String.format("%1$,.1f", cameraspecs.get(0).ox) + ", " + String.format("%1$,.1f", cameraspecs.get(0).oy) + ", " + String.format("%1$,.1f", cameraspecs.get(0).oz);
		g.drawString(str, 74 + cx, 53 + cy);

		// filter
		g.setFont(new Font("Arial", Font.PLAIN, 12));
		g.setColor(myBlue);
		str = "filter";
		g.drawString(str, 10 + cx, 69 + cy);

		g.setColor(myBlack);
		str = "" + cameraspecs.get(0).fr + ", " + cameraspecs.get(0).fg + ", " + cameraspecs.get(0).fb;
		g.drawString(str, 74 + cx, 69 + cy);

		// view angle
		g.setFont(new Font("Arial", Font.PLAIN, 12));
		g.setColor(myBlue);
		str = "viewangle";
		g.drawString(str, 10 + cx, 85 + cy);

		g.setColor(myBlack);
		str = "" + cameraspecs.get(0).viewx + ", " + cameraspecs.get(0).viewy;
		g.drawString(str, 74 + cx, 85 + cy);

		// resolution
		g.setFont(new Font("Arial", Font.PLAIN, 12));
		g.setColor(myBlue);
		str = "resolution";
		g.drawString(str, 10 + cx, 101 + cy);

		g.setColor(myBlack);
		str = "" + cameraspecs.get(0).resx + " x " + cameraspecs.get(0).resy;
		g.drawString(str, 74 + cx, 101 + cy);

		// noise
		g.setFont(new Font("Arial", Font.PLAIN, 12));
		g.setColor(myBlue);
		str = "noise";
		g.drawString(str, 175 + cx, 37 + cy);

		g.setColor(myBlack);
		str = "" + cameraspecs.get(0).raynoise;
		g.drawString(str, 230 + cx, 37 + cy);

		// distortion
		g.setFont(new Font("Arial", Font.PLAIN, 12));
		g.setColor(myBlue);
		str = "distortion";
		g.drawString(str, 175 + cx, 53 + cy);

		g.setColor(myBlack);
		str = "" + cameraspecs.get(0).distortion;
		g.drawString(str, 230 + cx, 53 + cy);

		// force the camera image have a height of 200?  Not implemented
		CameraSensor camera = new CameraSensor();
		//ObstacleMap omap = new ObstacleMap();
		int rd, grn, bl;
		for (int yy = 0; yy < camera.height; yy++) {
			for (int xx = 0; xx < camera.width; xx++) {
				rd = camera.img[xx][yy][0];// - (omap.obst[xx][yy] * 20);
				grn = camera.img[xx][yy][1];// - (omap.obst[xx][yy] * 20);
				bl = camera.img[xx][yy][2];// - (omap.obst[xx][yy] * 20);
				if (rd < 0)
					rd = 0;
				if (grn < 0)
					grn = 0;
				if (bl < 0)
					bl = 0;
				g.setColor(new Color(rd, grn, bl));
				g.fillRect(xx + cx + 5, ((camera.height - 1)-yy)+componentHeight-205+cy, 1, 1);
			}
		}
	}

	public void paintObstacleInformation(Graphics g, int cx, int cy) {
		int componentWidth = 258, componentHeight = 310;

        g.setColor(new Color(200, 200, 200));
        g.fillRect(cx, cy, componentWidth, componentHeight);
        
		g.setColor(new Color(230, 230, 230));
        g.fillRect(cx + 5, cy + 5, componentWidth-10, componentHeight-10);

		g.setFont(new Font("Arial", Font.PLAIN, 16));
		g.setColor(myBlack);
		String str = "Obstacles (" + obstacles.size() + "):";
		g.drawString(str, 10 + cx, 22 + cy);
	
		g.setFont(new Font("Arial", Font.PLAIN, 12));
		g.setColor(myBlue);
		str = "segment";
		g.drawString(str, 30 + cx, 37 + cy);

		g.setColor(myBlack);
		int yinc = 16;
		for (int i = 0; i < obstacles.size(); i++) {
			str = "" + i + ":  (" + (int)obstacles.get(i).sx + ", " + (int)obstacles.get(i).sy + ") -> (" + (int)obstacles.get(i).ex + ", " + (int)obstacles.get(i).ey + ")";
			g.drawString(str, 10 + cx, 37 + yinc * (i+1) + cy);
		}

		g.setColor(myBlue);
		str = "color";
		g.drawString(str, 168 + cx, 37 + cy);

		g.setColor(myBlack);
		for (int i = 0; i < obstacles.size(); i++) {
			str = "" + obstacles.get(i).rd + ", " + obstacles.get(i).gn + ", " + obstacles.get(i).bl;
			g.drawString(str, 165 + cx, 37 + yinc * (i+1) + cy);
		}
	}

	public void paintWorldFrame(Graphics g, int cx, int cy) {
		int componentWidth = 310, componentHeight = 310;

        g.setColor(new Color(200, 200, 200));
        g.fillRect(cx, cy, componentWidth, componentHeight);

        g.setColor(new Color(230, 230, 230));
        g.fillRect(cx + 5, cx + 5, componentWidth-10, componentHeight-10);

		// draw the chargers
		for (int i = 0; i < chargers.size(); i++) {
			double w = chargers.get(i).width * 3.0;
			double h = chargers.get(i).height * 3.0;
			double x = chargers.get(i).x * 3.0 + 5.0;
			double y = (100.0 - chargers.get(i).y) * 3.0 + 5.0;
			g.setColor(new Color((float)chargers.get(i).rd, (float)chargers.get(i).gn, (float)chargers.get(i).bl));
			g.fillRect((int)(x - (w / 2.0) + 0.5) + cx, (int)(y - (h / 2.0) + 0.5) + cy, (int)(w + 0.5), (int)(h + 0.5));
		}
		
		// draw the robots
		for (int i = 0; i < robots.size(); i++) {
			double w = robots.get(i).width * 3.0;
			double h = robots.get(i).height * 3.0;
			double x = robots.get(i).x * 3.0 + 5.0;
			double y = (100.0 - robots.get(i).y) * 3.0 + 5.0;
			g.setColor(new Color((float)robots.get(i).rd, (float)robots.get(i).gn, (float)robots.get(i).bl));
			g.fillOval((int)(x - (w / 2.0) + 0.5) + cx, (int)(y - (h / 2.0) + 0.5) + cy, (int)(w + 0.5), (int)(h + 0.5));

			double theta = robots.get(i).theta * Math.PI / 180.0;
			double dx = Math.cos(theta) * w / 2.0;
			double dy = Math.sin(theta) * w / 2.0;
			g.setColor(myOrange);
			g.drawLine((int)(x + 0.5) + cx, (int)(y + 0.5) + cy, (int)(x + dx), (int)(y - dy));
		}
		
		// draw the obstacles
		for (int i = 0; i < obstacles.size(); i++) {
			double sx = obstacles.get(i).sx * 3.0 + 5.0;
			double sy = (100.0 - obstacles.get(i).sy) * 3.0 + 5.0;
			double ex = obstacles.get(i).ex * 3.0 + 5.0;
			double ey = (100.0 - obstacles.get(i).ey) * 3.0 + 5.0;
			g.setColor(new Color((float)obstacles.get(i).rd, (float)obstacles.get(i).gn, (float)obstacles.get(i).bl));
			g.drawLine((int)(sx + 0.5) + cx, (int)(sy + 0.5) + cy, (int)(ex + 0.5), (int)(ey + 0.5));
		}

		// see whether the simulation is on or off
		if (!simulationOn) {
			g.setFont(new Font("Courier", Font.PLAIN, 21));
			g.setColor(myOrange);
			g.drawString("Simulation Off", componentWidth / 5 + cx, (componentHeight / 3) + cy);
		}
	}
}

class viewer extends JFrame implements KeyListener, ComponentListener {
    myCanvas canvas;
    Color bkgroundColor = new Color(0, 0, 0);
	boolean shown = false;

    viewer(int _screenWidth, int _screenHeight) {
        setSize(_screenWidth, _screenHeight + 22);
        getContentPane().setBackground(bkgroundColor);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(500, 0, _screenWidth, _screenHeight + 22);
        canvas = new myCanvas();
		addKeyListener(this);
		addComponentListener(this);
        getContentPane().add(canvas);
        setVisible(true);
        setTitle("The Viewer");

		shown = true;
    }

	public void componentHidden(ComponentEvent e) {}

    public void componentMoved(ComponentEvent e) {
		if (!shown)
			return;

		Point p = getContentPane().getLocationOnScreen();
		canvas.updateScreenPosition(p.x, p.y);
    }

    public void componentResized(ComponentEvent e) {}

    public void componentShown(ComponentEvent e) {}

	public void keyReleased(KeyEvent e) {}
	public void keyTyped(KeyEvent e) {}

	public void keyPressed(KeyEvent e) {
		int keyCode = e.getKeyCode();
    	switch (keyCode) { 
        	case KeyEvent.VK_UP:
            	//System.out.println("up arrow");
				writeControl(0, 1);
            	break;
        	case KeyEvent.VK_DOWN:
				//System.out.println("down arrow");
				writeControl(0, 0);
            	break;
        	case KeyEvent.VK_LEFT:
				//System.out.println("left arrow");
				writeControl(1, 1);
            	break;
        	case KeyEvent.VK_RIGHT:
				//System.out.println("right arrow");
				writeControl(-1, 1);
            	break;
			case KeyEvent.VK_Q:
				quitSimulation();
				break;
     	}
	}

	public void quitSimulation() {
		try {
			// now write the information to the appropriate robotactuators file
			String fnombre = "../MundoVerdadero/State/sim.txt";
			BufferedWriter writer = new BufferedWriter(new FileWriter(fnombre));		

			writer.write("off\n");

			writer.close();
		}
		catch (IOException e) {
			System.out.println(e);
		}		
	}

	public void writeControl(int direction, double rate) {
		try {
			// first, find out which robot is being controlled
			String file = "../MundoVerdadero/State/keyFocusIndex.txt";
			String str;
			BufferedReader reader = new BufferedReader(new FileReader(file));				
			str = reader.readLine();
			int rindex = Integer.parseInt(str);
			reader.close();
	
			// now write the information to the appropriate robotactuators file
			String fnombre = "../MundoVerdadero/State/robotactuators_" + rindex + ".txt";
			BufferedWriter writer = new BufferedWriter(new FileWriter(fnombre));		

			writer.write("rate " + rate + "\ndirection " + direction + "\n");

			writer.close();
		}
		catch (IOException e) {
			System.out.println(e);
		}		
	}

    public static void main(String args[]) {
        new viewer(850, 315);
    }
}
